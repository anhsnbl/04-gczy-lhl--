export const environment = {
  production: true,
  domain:'http://119.23.34.67:8080/'
};
