import { Component, OnInit } from '@angular/core';
import {Validators,FormControl,FormGroup,FormBuilder} from '@angular/forms';
import { NgbActiveModal } from '@ng-bootstrap/ng-bootstrap';
import {ToastService} from "../shared/toast/toast.service";
import {CustomValidators} from "../shared/custom-validator/custom-validator";
import {ToastConfig, ToastType} from "../shared/toast/toast-model";
import {Router} from "@angular/router";
import {Http,Jsonp,Headers} from "@angular/http";
import {environment} from "../../environments/environment";

@Component({
  selector: 'app-register',
  templateUrl: './register.component.html',
  styleUrls: ['./register.component.scss']
})
export class RegisterComponent implements OnInit {
  registerForm: FormGroup;
  headers = new Headers({'Content-Type': 'application/json'});
  dataList:Array<any>=[
    {
        "id":"1",
       "type":"教师"
    },{
      "id":"2",
      "type":"学生"
    }
  ];
  choose:string='1';
  constructor(private toastService: ToastService,
              private router: Router,
              private http:Http,
              private formBuilder: FormBuilder) {
    let name=new FormControl('', null);
    let schoolNumber=new FormControl('',  null);
    let phone=new FormControl('',  null);
    let password = new FormControl('', Validators.compose([Validators.required, Validators.minLength(6), Validators.maxLength(15)]));
    let certainPassword = new FormControl('', CustomValidators.equalTo(password));

    this.registerForm = this.formBuilder.group({
      schoolNumber:schoolNumber,//学号
      name: name,//姓名
      phone:phone,//number
      password: password,//密码
      certainPassword: certainPassword
    });
  }
  /**
   * 上传
   */
  ok(): void {
    this.router.navigate(['login']);
  }
  getChange7(uid: string) {
    this.choose=uid;
    console.log('========='+this.choose);

  }
  submit():void {
    // console.log(this.registerForm.controls['schoolNumber'].value+' '+this.registerForm.controls['name'].value+'/'+
    //   this.registerForm.controls['password'].value+'/'+
    //   this.registerForm.controls['certainPassword'].value+'/');
    let that = this;
    let str=environment.domain+'/register/'+this.choose+'/'+
      this.registerForm.controls['name'].value+'/'+
      this.registerForm.controls['schoolNumber'].value+'/'+
      this.registerForm.controls['certainPassword'].value+'/'+
      this.registerForm.controls['phone'].value+'/'+
      'null';
    console.log(str);
   // let str='http://172.17.175.62:8080/register/2/kangkang/N170327022/123123/1111111111/男';
    //let url = this.userBusinessService.login() +this.stOrTa+'/'+ this.loginForm.controls['userName'].value + '/' + this.loginForm.controls['password'].value;
    this.http.get(str).subscribe(
      function (data) {
        // if (JSON.parse(data['_body']).flag == true) {
        //   // const toastCfg = new ToastConfig(ToastType.SUCCESS, '', data, 3000);
        //   // that.toastService.toast(toastCfg);
        //   that.router.navigate(['/app/home']);
        //   console.log(data);
        // }
        if (JSON.parse(data['_body']).flag == true) {
          console.log('得到签到情况：' + data['_body']);
          const toastCfg = new ToastConfig(ToastType.SUCCESS, '', '注册成功', 3000);
          that.toastService.toast(toastCfg);
          console.log(JSON.parse(data['_body']).message);
        } else {
          const toastCfg = new ToastConfig(ToastType.ERROR, '', '用户已存在', 3000);
          that.toastService.toast(toastCfg);
          console.log(JSON.parse(data['_body']).message);
        }
      },
      function (err) {
        // const toastCfg = new ToastConfig(ToastType.ERROR, '', '密码错误', 3000);
        // this.toastService.toast(toastCfg);
        console.log('失败');
      });
    // //this.router.navigate(['login']);
    // let result=this.http.post(str,JSON.stringify({password: '123456'}), {headers:this.headers}).subscribe(
    //                 function(res){
    //                 console.log(res.json());
    //                 });

    // this.jsonp.get(str)
    //  .subscribe(
    //  function(data)
    //  {
    //   console.log(data)
    //  });
  }

  /**
   * 关闭
   */
  close(): void {
    this.router.navigate(['login']);
  };

  ngOnInit() {
  }

}
