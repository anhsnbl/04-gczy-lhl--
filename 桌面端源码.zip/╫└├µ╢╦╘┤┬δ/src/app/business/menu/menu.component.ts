import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'c-menu',
  template: '<router-outlet></router-outlet>'
})
export class MenuComponent {

}
