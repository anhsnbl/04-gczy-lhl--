import { Component, OnInit } from '@angular/core';
import {NgbModal} from '@ng-bootstrap/ng-bootstrap';

import  { ModalService } from '../../shared/modal/modal.service';
import {TodoObjData, NeedReadObjData, NoticeObjData, CommonFuncData, teachObjData} from '../home/home-model';

import  { PasswordEditComponent} from '../../business-shared/user/password-edit/password-edit.component';
import {LocalStorageService} from "../../shared/storage/local-storage.service";


@Component({
  selector: 'c-home',
  templateUrl: './home.component.html',
  styleUrls:['./home.component.scss']
})
export class HomeComponent implements OnInit {

  userTipClose:boolean=false;
  isTodoCollapsed:boolean=false;
  isNoticeCollapsed:boolean=false;
  isNeedReadCollapsed:boolean=false;
  isTeachCollapsed:boolean=false;
  isCommonFuncCollapsed:boolean=false;


  todoObj: TodoObjData = {
    total: 5,
    todoList: [{
      id: 1,
      title: '取邮件通知',
      submitUser: '[05-08]',
      createDate: '2018-07-08'
    }, {
      id: 2,
      title: '关于召开全院教职工大会的通知',
      submitUser: '[05-27]',
      createDate: '2018-05-23'
    }, {
      id: 3,
      title: '第十九届中国青年信息与管理学者大会征文通知',
      submitUser: '[05-22]',
      createDate: '2018-05-02'
    }, {
      id: 4,
      title: '2017年福州大学第十三届数学建模竞赛题目',
      submitUser: '[06-02]',
      createDate: '2018-06-02'
    }, {
      id: 5,
      title: '第十五届中国不确定系统年会征文通知',
      submitUser: '[06-12]',
      createDate: '2018-06-12'
    }]
  };

  needReadObj: TodoObjData = {
    total: 5,
    todoList: [{
      id: 1,
      title: '计算机科学与技术专业圆满完成中国工程教育专业认证现场',
      submitUser: '[06-08]',
      createDate: '2018-06-08'
    }, {
      id: 2,
      title: '中国自动化学会“粒计算与多尺度分析专业委员会”成立',
      submitUser: '[06-13]',
      createDate: '2018-06-13'
    }, {
      id: 3,
      title: '我院组织部分党员赴宁德金涵畲族乡亭坪村参观学习',
      submitUser: '[05-23]',
      createDate: '2018-05-23'
    }, {
      id: 4,
      title: '2017年福州大学第十三届数学建模竞赛题目',
      submitUser: '[06-02]',
      createDate: '2018-06-02'
    }, {
      id: 5,
      title: '福州大学首届“国际青年学者论坛”数计学院分论坛顺利举行',
      submitUser: '[05-17]',
      createDate: '2018-05-17'
    }]
  };

  noticeObj: TodoObjData = {
    total: 5,
    todoList: [{
      id: 1,
      title: '关于转发《福建省科学技术厅关于组织申报第二批省级新型研发机构的通知》的通知',
      submitUser: '[05-20]',
      createDate: '2018-05-20'
    }, {
      id: 2,
      title: '关于转发“军委装备发展部信息系统局2017年重大专项第一批项目指南（外网公开）发布公告”的通知',
      submitUser: '[05-19]',
      createDate: '2018-05-19'
    }, {
      id: 3,
      title: '转发国家自然科学基金委员会-国家电网公司智能电网联合基金2017年度项目指南有关文件的通知',
      submitUser: '[05-19]',
      createDate: '2018-05-19'
    }, {
      id: 4,
      title: '“非可控性炎症恶性转化的调控网络及其分子机制”等五个重大研究计划2017年度项目指南有关文件的通知',
      submitUser: '[05-19]',
      createDate: '2018-05-19'
    }, {
      id: 5,
      title: '关于转发《福建省发展和改革委员会关于做好生物与新医药',
      submitUser: '[05-19]',
      createDate: '2018-05-19'
    }]
  }

  teachObj: TodoObjData = {
    total: 5,
    todoList: [{
      id: 1,
      title: '福州大学数学与计算机科学学院2018年招收推免生复试方案及实施细则',
      submitUser: '[04-08]',
      createDate: '2018-04-08'
    }, {
      id: 2,
      title: '任课教师实验室更新软件的通知',
      submitUser: '[05-23]',
      createDate: '2018-05-23'
    }, {
      id: 3,
      title: '201602学期公共数学补考安排表',
      submitUser: '[05-30]',
      createDate: '2018-05-30'
    }, {
      id: 4,
      title: '2017年参加数学与计算机学院研究生夏令营名单',
      submitUser: '[05-30]',
      createDate: '2018-05-30'
    }, {
      id: 5,
      title: '201802学期公共数学期末考试监考',
      submitUser: '[05-20]',
      createDate: '2018-05-20'
    }]
  }


  commonFuncConfigTip: string = "配置常用功能";

  /**
   * 初始化
   */
  ngOnInit() {

  }
  userName:string='';
  constructor(private modalService: ModalService,
  private ngbModalService: NgbModal,
  private localStorage:LocalStorageService){
     this.userName=this.localStorage.get('userName');
  }


  /**
   * 修改密码
   */
  passwordEdit(){
      this.ngbModalService.open(PasswordEditComponent,{size:'lg'}).result.then((result) => {

      }, (reason) => {

      });
  }




}
