import { Component, OnInit } from '@angular/core';
import {FormBuilder, FormControl, FormGroup, Validators} from "@angular/forms";
import {Http} from "@angular/http";
import {LocalStorageService} from "../../../shared/storage/local-storage.service";
import {ToastService} from "../../../shared/toast/toast.service";
import {environment} from "../../../../environments/environment";
import {ToastConfig, ToastType} from "../../../shared/toast/toast-model";

@Component({
  selector: 'app-user-query',
  templateUrl: './user-query.component.html',
  styleUrls: ['./user-query.component.scss']
})
export class UserQueryComponent implements OnInit {
  userqueryForm: FormGroup;
  userInfo:string;
  dataList:Array<any>=[];
  constructor(private formBuilder: FormBuilder,
              private http:Http,
              private localStorage: LocalStorageService,
              private toastService: ToastService) {
    let queryNum=new FormControl('', Validators.compose([Validators.required]));
    this.userqueryForm = this.formBuilder.group({
      queryNum:queryNum,//起始开始时
    });
  }

  addData() {
    let that = this;
    let data = this.localStorage.get('userData');
    let isStOrTe = this.localStorage.get('stOrTa');
    let url = environment.domain + '/info/user/' + isStOrTe + '/' + JSON.parse(data).roleNO;//该学生信息
    this.http.get(url).subscribe(
      function (data) {
        if (JSON.parse(data['_body']).flag == true) {
          // const toastCfg = new ToastConfig(ToastType.SUCCESS, '', data, 3000);
          // that.toastService.toast(toastCfg);
          that.userInfo = JSON.parse(data['_body']).user;
          that.dataList[0]=that.userInfo;
         // that.userInfo=JSON.parse(JSON.parse(data['_body']).user);
          console.log(that.dataList[0]);
        } else {
          const toastCfg = new ToastConfig(ToastType.ERROR, '', '没有该学生', 3000);
          that.toastService.toast(toastCfg);
          console.log(JSON.parse(data['_body']).message);
        }
      },
      function (err) {
        const toastCfg = new ToastConfig(ToastType.ERROR, '', '没有该学生', 3000);
        that.toastService.toast(toastCfg);
        console.log('失败');
      });
    //
// this.http.post(url,JSON.stringify({password: '123456'})).subscribe(
//                     function(res){
//                     console.log('post的方法'+res.json().list);
//                     });;
//   }
  }

  submit(){
    console.log(this.userqueryForm.controls['queryNum'].value);
    this.addData();
  }
  ngOnInit() {
  }

}
