import { Component, OnInit } from '@angular/core';
import { AppService } from '../../../app.service';
import {LocalStorageService} from "../../../shared/storage/local-storage.service";

@Component({
  selector: 'c-user-info',
  templateUrl: './user-info.component.html'
})
export class UserInfoComponent {
  userName:string='';
  userInfo:any;
  constructor(private appService: AppService,
              private localStorage: LocalStorageService) {
    this.userName=this.localStorage.get('userName');
    this.appService.titleEventEmitter.emit("个人资料");
    let data = this.localStorage.get('userData');
    this.userInfo= JSON.parse(data).user;
    console.log(this.userInfo);
  }
}
