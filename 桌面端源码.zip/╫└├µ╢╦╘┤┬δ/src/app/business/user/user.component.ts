import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'c-user',
  template: '<router-outlet></router-outlet>'
})
export class UserComponent  {

}