import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'c-role',
  template: '<router-outlet></router-outlet>'
})
export class RoleComponent  {

}