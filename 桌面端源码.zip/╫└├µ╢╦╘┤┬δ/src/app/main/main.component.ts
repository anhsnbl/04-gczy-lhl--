import { Component, OnInit, ElementRef, ViewChild } from '@angular/core';
import { Router } from '@angular/router';
import { NgbModal } from '@ng-bootstrap/ng-bootstrap';


import { MainData } from '../main/main-model';
import { ModalService } from '../shared/modal/modal.service';
import { ConfirmConfig } from '../shared/modal/modal-model';

import { AvatarCropperComponent } from '../business-shared/user/avatar-cropper/avatar-cropper.component';
import { PasswordEditComponent } from '../business-shared/user/password-edit/password-edit.component';
import { AppService } from '../app.service';
import {LocalStorageService} from "../shared/storage/local-storage.service";

/**
 * 主体组件
 */
@Component({
  selector: 'c-main',
  templateUrl: './main.component.html',
  styleUrls: ['.//main.component.scss']
})
export class MainComponent implements OnInit {

  //切换导航
  toggleDescTip: string = "点击关闭导航菜单";

  //切换导航标识
  navClose: boolean = false;

  //用户数据
  mainData: MainData;

  title: string = "首页";
  userName:string='';

  constructor(private router: Router,
              private modalService: ModalService,
              private ngbModalService: NgbModal,
              private appService: AppService,
              private localStorage: LocalStorageService) {
    this.appService.titleEventEmitter.subscribe((value: string) => {
      if (value) {
        this.title = value;
      }
    });
    this.userName=this.localStorage.get('userName');
    console.log('转到main后：'+this.localStorage.get('stOrTa')+' '+this.localStorage.get('userName'));
    this.isTeahch();
  }
  isTeahch(){
    if (parseInt(this.localStorage.get('stOrTa'))==1) {
      this.mainData = {
        userData: {
          userName: this.localStorage.get('userName'),
          userAvatar: './assets/img/user-header.png',
          mobilePhone: '1565919',
          email: '410982576@',
          positions: 'zh',
        },
        menuData: [
          {
            "id": "01",
            "parentId": "0",
            "name": "学生管理",
            "keyWord": "yssl",
            "icon": 'fa-cubes',
            "isExpend": true,
            "children": [
              {
                "id": "011",
                "parentId": "01",
                "name": "学生查询",
                "keyWord": "query",
                "icon": 'fa-cubes',
                "url": '/app/user/userQuery'
              }, {
                "id": "012",
                "parentId": "01",
                "name": "学生列表",
                "keyWord": "list",
                "icon": 'fa-cubes',
                "url": '/app/user/userList'
              }
            ]
          },
          {
            "id": "02",
            "parentId": "0",
            "name": "课程管理",
            "keyWord": "course",
            "icon": 'fa-user',
            "isExpend": true,
            "children": [{
              "id": "021",
              "parentId": "02",
              "name": "教学课程",
              "keyWord": "yhgl",
              "icon": "fa-user-circle-o",
              "url": 'app/course/coursedetail'}
            // },
            //   {
            //     "id": "022",
            //     "parentId": "02",
            //     "name": "选课安排",
            //     "keyWord": "list",
            //     "icon": 'fa-cubes',
            //     "url": 'app/course/coursearrange'
            //   }
            ]
          },
          {
            "id": "03",
            "parentId": "0",
            "name": "签到管理",
            "keyWord": "sign",
            "icon": 'fa-user',
            "isExpend": true,
            "children": [{
              "id": "031",
              "parentId": "03",
              "name": "签到情况",
              "keyWord": "yhgl",
              "icon": "fa-user-circle-o",
              "url": 'app/sign/signdetail'
            },
              {
                "id": "032",
                "parentId": "03",
                "name": "签到设置",
                "keyWord": "list",
                "icon": 'fa-cubes',
                "url": 'app/sign/signset'
              }
            ]
          },{
            "id": "06",
            "parentId": "0",
            "name": "个人管理",
            "keyWord": "yssl",
            "icon": 'fa-cubes',
            "isExpend": true,
            "children": [
              {
                "id": "061",
                "parentId": "06",
                "name": "个人信息",
                "keyWord": "query",
                "icon": 'fa-cubes',
                "url": 'app/user/userInfo'}
              // }, {
              //   "id": "062",
              //   "parentId": "06",
              //   "name": "学生列表",
              //   "keyWord": "list",
              //   "icon": 'fa-cubes',
              //   "url": '/app/user/userList'
              // }
            ]
          }
        ]
      }
    }else{
      this.mainData = {
        userData: {
          userName: this.localStorage.get('userName'),
          userAvatar: './assets/img/user-header.png',
          mobilePhone: '1565919',
          email: '410982576@',
          positions: 'zh',
        },
        menuData: [
         {
            "id": "04",
            "parentId": "0",
            "name": "课程管理",
            "keyWord": "sign",
            "icon": 'fa-user',
            "isExpend": true,
            "children": [{
              "id": "041",
              "parentId": "04",
              "name": "学期课程",
              "keyWord": "yhgl",
              "icon": "fa-user-circle-o",
              "url": 'app/student/studentcourse'
            },
              {
                "id": "042",
                "parentId": "04",
                "name": "签到情况",
                "keyWord": "list",
                "icon": 'fa-cubes',
                "url": 'app/student/studentsign'
              }
            ]
          },{
            "id": "05",
            "parentId": "0",
            "name": "课程管理",
            "keyWord": "sign",
            "icon": 'fa-user',
            "isExpend": true,
            "children": [
              {
                "id": "051",
                "parentId": "05",
                "name": "个人信息",
                "keyWord": "list",
                "icon": 'fa-cubes',
                "url": 'app/user/userInfo'
              },
            ]
          }

        ]
      }
    }
}

  /**
   * 初始化
   */
  ngOnInit() {
  }

  /**
    * 切换导航
   */
  toggleNav() {
    this.navClose = !this.navClose;
    if (this.navClose) {
      this.toggleDescTip = "点击展开导航菜单";
    } else {
      this.toggleDescTip = "点击关闭导航菜单";
    }
  }

  /**
   * 跳转首页
   */
  toHome() {
    this.title = "首页";
    this.router.navigate(['/app/home']);
  }

  /**
   * 个人资料
   */
  userInfo() {
    this.router.navigate(['/app/user/userInfo']);
  }

  /**
   * 头像更换
   */
  avatarReplacement() {
    this.ngbModalService.open(AvatarCropperComponent, { size: 'lg', backdrop: 'static', keyboard: false }).result.then((result) => {

    }, (reason) => {

    });
  }

  /**
   * 修改密码
   */
  passwordEdit() {
    this.ngbModalService.open(PasswordEditComponent, { size: 'lg' }).result.then((result) => {

    }, (reason) => {

    });
  }


  /**
   * 退出系统
   */
  exitSys() {
    let exitSysCfg = new ConfirmConfig('您确定退出系统吗？');
    this.modalService.confirm(exitSysCfg).then((result) => {
      if (result.status == "approved") {
        this.router.navigate(['/login']);
      }
    }, (reason) => {
    });
  }





}


