import { NgModule }   from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import {SignComponent} from "./sign.component";
import {SigndetailComponent} from "./signdetail/signdetail.component";
import {SignsetComponent} from "./signset/signset.component";

const signRoutes: Routes = [
  {
    path: 'signdetail',
    component: SigndetailComponent
  },
  {
    path: 'signset',
    component: SignsetComponent
  }
]


@NgModule({
  imports: [
    RouterModule.forChild(signRoutes)
  ],
  exports: [
    RouterModule
  ]
})
export class SignRoutingModule { }
