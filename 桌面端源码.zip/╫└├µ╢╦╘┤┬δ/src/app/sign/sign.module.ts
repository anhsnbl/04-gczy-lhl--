
import {NgModule} from "@angular/core";
import {SignRoutingModule} from "./sign-routing.module";
import {SignComponent} from "./sign.component";
import {SignsetComponent} from "./signset/signset.component";
import {SigndetailComponent} from "./signdetail/signdetail.component";
import {FormsModule, ReactiveFormsModule} from "@angular/forms";
import {CommonModule} from "@angular/common";

@NgModule({
  imports: [
    SignRoutingModule,
    FormsModule,
    ReactiveFormsModule,
    CommonModule
  ],
  declarations: [
    SignComponent,
    SignsetComponent,
    SigndetailComponent
  ],
  exports: [
  ],
  providers: []
})
export class SignModule { }
