import { Component, OnInit } from '@angular/core';
import {FormBuilder, FormControl, FormGroup, Validators} from "@angular/forms";
import {ToastService} from "../../shared/toast/toast.service";
import {ToastConfig, ToastType} from "../../shared/toast/toast-model";
import {number} from "../../shared/custom-validator/number/number";
import {Http} from "@angular/http";
import {environment} from "../../../environments/environment";
import {LocalStorageService} from "../../shared/storage/local-storage.service";
import {courseData} from "../../course/coursedetail/coursedetail-model";

@Component({
  selector: 'app-signset',
  templateUrl: './signset.component.html',
  styleUrls: ['./signset.component.scss']
})
export class SignsetComponent implements OnInit {
  signForm: FormGroup;
  totalData:string;
  dataList:Array<courseData>=[];
  choose:string='';
  constructor(private formBuilder: FormBuilder,
              private http:Http,
              private localStorage: LocalStorageService,
              private toastService: ToastService) {
    let formHour=new FormControl('', Validators.compose([Validators.required]));
    let fromMini=new FormControl('',  Validators.compose([Validators.required]));
    let toHour=new FormControl('',  Validators.compose([Validators.required]));
    let toMini=new FormControl('',  Validators.compose([Validators.required]));
    this.signForm = this.formBuilder.group({
      formHour:formHour,//起始开始时
      fromMini: fromMini,//起始开始分
      toHour:toHour,//结束时
      toMini:toMini//结束分
    });
    this.addData();
  }
  ngOnInit() {
  }

  getChange2(uid: string) {
    console.log('=========');
    this.choose=uid;
  }

  addData() {
    let that = this;
    let data = this.localStorage.get('userData');
    let isStOrTe = this.localStorage.get('stOrTa');
    let url = environment.domain + '/list/course/' + isStOrTe + '/' + JSON.parse(data).roleNO;//该用户所有课程
    this.http.get(url).subscribe(
      function (data) {
        if (JSON.parse(data['_body']).flag == true) {
          // const toastCfg = new ToastConfig(ToastType.SUCCESS, '', data, 3000);
          // that.toastService.toast(toastCfg);
          let a = data['_body'].toString();
          let cData = a.substring(parseInt(a.indexOf('[')),parseInt(a.indexOf(']')+1));
          console.log('该教师的课程：' +cData);
          //转换json
          let jsonArr = '[{"courseID":1,"course":"计算机工程实训","courseNO":"C170327001","teacherNO":"T170327001","classroom":"数计中-307","week":2,"start":"23:30","end":"23:50","period":"1-11"}]';
          that.totalData = cData;
          that.tranData();
        } else {
          const toastCfg = new ToastConfig(ToastType.ERROR, '', '没有课程', 3000);
          that.toastService.toast(toastCfg);
          console.log(JSON.parse(data['_body']).message);
        }
      },
      function (err) {
        const toastCfg = new ToastConfig(ToastType.ERROR, '', '没有课程', 3000);
        that.toastService.toast(toastCfg);
        console.log('失败');
      });
    //
// this.http.post(url,JSON.stringify({password: '123456'})).subscribe(
//                     function(res){
//                     console.log('post的方法'+res.json().list);
//                     });;
//   }
  }

  tranData(){
    let i=0,j=0;
    let objArr=JSON.parse(this.totalData);
    if(objArr.length>0)
       this.choose=objArr[0].courseNO;
    for (;i<objArr.length;i++) {
      console.log(objArr[i]);
      this.dataList[i]=objArr[i];
      // this.dataList[i].courseID = objArr[i].courseID;
      // this.dataList[i].course = objArr[i].course;
      // this.dataList[i].courseNO = objArr[i].courseNO;
      // this.dataList[i].teacherNO = objArr[i].teacherNO;
      // this.dataList[i].classroom = objArr[i].classroom;
      // this.dataList[i].week = objArr[i].week;
      // this.dataList[i].start = objArr[i].start;
      // this.dataList[i].end = objArr[i].end;
    }
  }

  submit():void {
    let that = this;
    console.log(parseInt(this.signForm.controls['formHour'].value) + '/' + this.signForm.controls['fromMini'].value + '/' +
      this.signForm.controls['toHour'].value + '/' + this.signForm.controls['toMini'].value + '/');
    let a=parseInt(this.signForm.controls['formHour'].value);
    let b=parseInt(this.signForm.controls['fromMini'].value);
    let c=parseInt(this.signForm.controls['toHour'].value);
    let d=parseInt(this.signForm.controls['toMini'].value);
    console.log('转换后：'+a+'/'+b+'/'+c+'/'+d);
    if (a > c|| (a==c&&b>d)) {
      const toastCfg = new ToastConfig(ToastType.ERROR, '', '时间设置错误', 3000);
      this.toastService.toast(toastCfg);
      console.log('时间设置错误');
    }else{
      let data = that.localStorage.get('userData');
      let url=environment.domain+'setting/course/' + JSON.parse(data).roleNO+'/'+this.choose+'/'+a+':'+b+'/'+c+':'+d;
      this.http.get(url).subscribe(
        function (data) {
          if (JSON.parse(data['_body']).flag == true) {
            console.log('修改后的签到信息：' +data['_body']);
            const toastCfg = new ToastConfig(ToastType.SUCCESS, '', '修改成功', 3000);
            that.toastService.toast(toastCfg);
            console.log(JSON.parse(data['_body']).message);
          } else {
            const toastCfg = new ToastConfig(ToastType.ERROR, '', '修改失败', 3000);
            that.toastService.toast(toastCfg);
            console.log(JSON.parse(data['_body']).message);
          }
        },
        function (err) {
          const toastCfg = new ToastConfig(ToastType.ERROR, '', '修改失败', 3000);
          that.toastService.toast(toastCfg);
          console.log('失败');
        });
    }
  }
}
