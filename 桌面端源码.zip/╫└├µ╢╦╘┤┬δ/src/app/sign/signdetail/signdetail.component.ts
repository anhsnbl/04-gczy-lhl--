import { Component, OnInit } from '@angular/core';
import {FormBuilder, FormControl, FormGroup, Validators} from "@angular/forms";
import {ToastService} from "../../shared/toast/toast.service";
import {ToastConfig, ToastType} from "../../shared/toast/toast-model";
import {number} from "../../shared/custom-validator/number/number";
import {Http} from "@angular/http";
import {environment} from "../../../environments/environment";
import {LocalStorageService} from "../../shared/storage/local-storage.service";
import {courseData} from "../../course/coursedetail/coursedetail-model";

@Component({
  selector: 'app-signdetail',
  templateUrl: './signdetail.component.html',
  styleUrls: ['./signdetail.component.scss']
})
export class SigndetailComponent implements OnInit {
  otalData:string;
  dataList:Array<courseData>=[];
  studentList:Array<any>=[];//存储选择该课程学生
  showList:Array<any>=[];
  choose:string='';
  totalData:string;
  userSelectThis:string;

  //
  pageList:Array<number>= [15, 25, 35];
  pageNumber=1;//第几页
  pageTotal:any;//共几页
  nowSite=1;
  constructor(private formBuilder: FormBuilder,
              private http:Http,
              private localStorage: LocalStorageService,
              private toastService: ToastService) {
    this.addData();
  }

  ngOnInit() {
  }
  addData() {
    let that = this;
    let data = this.localStorage.get('userData');
    let isStOrTe = this.localStorage.get('stOrTa');
    let url = environment.domain + '/list/course/' + isStOrTe + '/' + JSON.parse(data).roleNO;//该用户所有课程
    this.http.get(url).subscribe(
      function (data) {
        if (JSON.parse(data['_body']).flag == true) {
          // const toastCfg = new ToastConfig(ToastType.SUCCESS, '', data, 3000);
          // that.toastService.toast(toastCfg);
          let a = data['_body'].toString();
          let cData = a.substring(parseInt(a.indexOf('[')),parseInt(a.indexOf(']')+1));
          console.log('该教师的课程：' +cData);
          //转换json
          let jsonArr = '[{"courseID":1,"course":"计算机工程实训","courseNO":"C170327001","teacherNO":"T170327001","classroom":"数计中-307","week":2,"start":"23:30","end":"23:50","period":"1-11"}]';
          that.totalData = cData;
          that.tranData();
        } else {
          const toastCfg = new ToastConfig(ToastType.ERROR, '', '没有课程', 3000);
          that.toastService.toast(toastCfg);
          console.log(JSON.parse(data['_body']).message);
        }
      },
      function (err) {
        const toastCfg = new ToastConfig(ToastType.ERROR, '', '没有课程', 3000);
        that.toastService.toast(toastCfg);
        console.log('失败');
      });
    //
// this.http.post(url,JSON.stringify({password: '123456'})).subscribe(
//                     function(res){
//                     console.log('post的方法'+res.json().list);
//                     });;
//   }
  }

  tranData(){
    let i=0,j=0;
    let objArr=JSON.parse(this.totalData);
    if(objArr.length>0)
      this.choose=objArr[0].courseNO;
    for (;i<objArr.length;i++) {
      console.log(objArr[i]);
      this.dataList[i]=objArr[i];
      // this.dataList[i].courseID = objArr[i].courseID;
      // this.dataList[i].course = objArr[i].course;
      // this.dataList[i].courseNO = objArr[i].courseNO;
      // this.dataList[i].teacherNO = objArr[i].teacherNO;
      // this.dataList[i].classroom = objArr[i].classroom;
      // this.dataList[i].week = objArr[i].week;
      // this.dataList[i].start = objArr[i].start;
      // this.dataList[i].end = objArr[i].end;
    }
    this.submit();
  }
  getChange3(uid: string) {
    console.log('=========');
    this.choose=uid;
  }

  trandata2(){//存储符合查询课程的学生
    let i=0;
    let objArr=JSON.parse(this.userSelectThis);
    console.log('学生'+objArr[0].student);
    for (;i<objArr.length;i++) {
      console.log(objArr[i]);
      this.studentList[i]=objArr[i];
    }
//计算页数
    if(this.studentList.length%15==0){
      this.pageTotal=this.studentList.length/15;
    }else{
      this.pageTotal=Math.trunc(this.studentList.length/15)+1;
    }
    for (let i = 0; i < this.studentList.length; i ++) {
      if(i>=(this.pageNumber-1)*15 && i<this.pageNumber*15)
      {
        this.showList[i] = this.studentList[i]; // 1, "string", false
      }
    }
  }

  submit():void {
    let that = this;
    let data = that.localStorage.get('userData');
    let url = environment.domain + 'list/course/attence/' + this.choose;
    this.http.get(url).subscribe(
      function (data) {
        if (JSON.parse(data['_body']).flag == true) {
          console.log('得到签到情况：' + data['_body']);
          const toastCfg = new ToastConfig(ToastType.SUCCESS, '', '查询成功', 3000);
          that.toastService.toast(toastCfg);
          console.log(JSON.parse(data['_body']).message);
          //处理返回数据
          let a = data['_body'].toString();
          let cData = a.substring(parseInt(a.indexOf('[')),parseInt(a.indexOf(']')+1));
          that.userSelectThis=cData;
          that.trandata2();
        } else {
          const toastCfg = new ToastConfig(ToastType.ERROR, '', '查询失败', 3000);
          that.toastService.toast(toastCfg);
          console.log(JSON.parse(data['_body']).message);
        }
      },
      function (err) {
        const toastCfg = new ToastConfig(ToastType.ERROR, '', '查询失败', 3000);
        that.toastService.toast(toastCfg);
        console.log('失败');
      });
  }

  back(){
    this.pageNumber--;
    this.showList=[];
    let j=0;
    for (let i = 0; i < this.studentList.length; i ++) {
      if(i>=(this.pageNumber-1)*15 && i<this.pageNumber*15)
      {
        this.showList[j] = this.studentList[i]; // 1, "string", false
        j++;
      }
    }
    this.nowSite=(this.pageNumber-1)*15;
  }
  next(){
    this.pageNumber++;
    this.showList=[];
    let j=0;
    for (let i = 0; i < this.studentList.length; i ++) {
      if(i>=(this.pageNumber-1)*15 && i<this.pageNumber*15)
      {
        this.showList[j] = this.studentList[i]; // 1, "string", false
        j++;
      }
    }
    this.nowSite=this.pageNumber*15;
  }
}
