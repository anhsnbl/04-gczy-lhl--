import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { SigndetailComponent } from './signdetail.component';

describe('SigndetailComponent', () => {
  let component: SigndetailComponent;
  let fixture: ComponentFixture<SigndetailComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ SigndetailComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(SigndetailComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
