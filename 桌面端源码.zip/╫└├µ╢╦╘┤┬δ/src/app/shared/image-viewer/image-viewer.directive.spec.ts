import { ImageViewerDirective } from './image-viewer.directive';

describe('ImageViewerDirective', () => {
  it('should create an instance', () => {
    const directive = new ImageViewerDirective();
    expect(directive).toBeTruthy();
  });
});
