/**
 * 主题
 */
export class SwitchTheme {
    public static THTME_PRIMARY: string = "c-switch-primary";
    public static THTME_SUCCESS: string = "c-switch-success";
    public static THTME_INFO: string = "c-switch-info";
    public static THTME_WARNING: string = "c-switch-warning";
    public static THTME_DANGER: string = "c-switch-danger";
}