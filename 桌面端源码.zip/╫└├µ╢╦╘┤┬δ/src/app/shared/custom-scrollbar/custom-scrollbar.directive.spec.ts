import { CustomScrollbarDirective } from './custom-scrollbar.directive';

describe('CustomScrollbarDirective', () => {
  it('should create an instance', () => {
    const directive = new CustomScrollbarDirective();
    expect(directive).toBeTruthy();
  });
});
