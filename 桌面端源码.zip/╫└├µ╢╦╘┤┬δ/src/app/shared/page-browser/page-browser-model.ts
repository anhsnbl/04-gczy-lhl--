/**
 * 配置
 */
export class PageBrowserConfig {
     title:string;
     url:string;
}

