import { ImgSelectDirective } from './img-select.directive';

describe('ImgSelectDirective', () => {
  it('should create an instance', () => {
    const directive = new ImgSelectDirective();
    expect(directive).toBeTruthy();
  });
});
