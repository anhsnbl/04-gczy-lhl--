import { SimpleDataTableDirective } from './simple-data-table.directive';

describe('SimpleDataTableDirective', () => {
  it('should create an instance', () => {
    const directive = new SimpleDataTableDirective();
    expect(directive).toBeTruthy();
  });
});
