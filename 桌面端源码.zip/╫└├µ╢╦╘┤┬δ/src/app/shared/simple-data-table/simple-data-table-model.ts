export class SortEvent {
    sortBy: string|string[];
    sortOrder: string
}

export class SortType{
     static ASC: string='asc';
     static DESC: string='desc';
}
