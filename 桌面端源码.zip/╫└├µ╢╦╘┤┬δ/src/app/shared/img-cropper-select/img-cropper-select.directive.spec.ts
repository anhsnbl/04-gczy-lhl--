import { ImgCropperSelectDirective } from './img-cropper-select.directive';

describe('ImgCropperSelectDirective', () => {
  it('should create an instance', () => {
    const directive = new ImgCropperSelectDirective();
    expect(directive).toBeTruthy();
  });
});
