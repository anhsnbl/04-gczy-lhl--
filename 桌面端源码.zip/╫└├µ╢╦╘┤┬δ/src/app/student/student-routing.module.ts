import { NgModule }   from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import {StudentsignComponent} from "./studentsign/studentsign.component";
import {StudentdetailComponent} from "./studentdetail/studentdetail.component";
import {StudentcourseComponent} from "./studentcourse/studentcourse.component";

const studentRoutes: Routes = [
  {
    path: 'studentdetail',
    component: StudentdetailComponent
  },
  {
    path: 'studentsign',
    component: StudentsignComponent
  },{
    path: 'studentcourse',
    component: StudentcourseComponent
  }
]


@NgModule({
  imports: [
    RouterModule.forChild(studentRoutes)
  ],
  exports: [
    RouterModule
  ]
})
export class StudentRoutingModule { }
