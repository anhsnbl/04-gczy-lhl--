import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-studentdetail',
  templateUrl: './studentdetail.component.html',
  styleUrls: ['./studentdetail.component.scss']
})
export class StudentdetailComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
