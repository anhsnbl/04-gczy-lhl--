import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { StudentsignComponent } from './studentsign.component';

describe('StudentsignComponent', () => {
  let component: StudentsignComponent;
  let fixture: ComponentFixture<StudentsignComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ StudentsignComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(StudentsignComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
