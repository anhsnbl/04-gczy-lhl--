
import {NgModule} from "@angular/core";
import {FormsModule, ReactiveFormsModule} from "@angular/forms";
import {StudentComponent} from "./student.component";
import { StudentdetailComponent } from './studentdetail/studentdetail.component';
import { StudentsignComponent } from './studentsign/studentsign.component';
import {StudentRoutingModule} from "./student-routing.module";
import {CommonModule} from "@angular/common";
import { StudentcourseComponent } from './studentcourse/studentcourse.component';

@NgModule({
  imports: [
    CommonModule,
    StudentRoutingModule,
    FormsModule,
    ReactiveFormsModule
  ],
  declarations: [
    StudentComponent,
    StudentdetailComponent,
    StudentsignComponent,
    StudentcourseComponent,
  ],
  exports: [
  ],
  providers: []
})
export class StudentModule { }
