import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { Validators, FormControl, FormGroup, FormBuilder } from '@angular/forms';

import { HttpService } from '../shared/http/http.service';
import {Http,Jsonp,Headers} from "@angular/http";
import { ToastService } from '../shared/toast/toast.service';
import { ToastConfig, ToastType } from '../shared/toast/toast-model';
import { CustomValidators } from '../shared/custom-validator/custom-validator';
import { UserBusinessService} from '../business-service/user/user-business.service';
import { Utils } from "../shared/util/utils";
import {PasswordEditComponent} from "../business-shared/user/password-edit/password-edit.component";
import {LocalStorageService} from "../shared/storage/local-storage.service";
import {environment} from "../../environments/environment";




@Component({
  selector: 'c-login',
  templateUrl: './login.component.html',
  styleUrls: ['./login.component.scss']
})
export class LoginComponent implements OnInit {

  loginForm: FormGroup;
  stOrTa:string='1';
  constructor(
    private router: Router,
    private toastService: ToastService,
    private httpService: HttpService,
    private userBusinessService:UserBusinessService,
    private http:Http,
    private localStorage: LocalStorageService,
    private formBuilder: FormBuilder) {
    let userNameFc = new FormControl('teacher', Validators.compose([Validators.required, Validators.minLength(1), Validators.maxLength(15)]));
    let passwordFc = new FormControl('123456', Validators.compose([Validators.required, Validators.minLength(1), Validators.maxLength(15)]));

    this.loginForm = this.formBuilder.group({
      userName: userNameFc,
      password: passwordFc
    });
  }

  /**
  * 初始化
  */
  ngOnInit() {

  }


  /**
   * 登录
   */
  // login() {
  //   if (this.loginForm.valid) {
  //     let that = this;
  //     this.httpService.post(this.userBusinessService.login()+this.loginForm.controls['userName'].value+'/'+this.loginForm.controls['password'].value, {
  //       userName:  this.loginForm.controls['userName'].value,
  //       password:  this.loginForm.controls['password'].value
  //     }, function (successful, data, res) {
  //       if (successful && Utils.resultSuccess(data.resultType)) {
  //         const toastCfg = new ToastConfig(ToastType.SUCCESS, '', data.resultMsg, 3000);
  //         that.toastService.toast(toastCfg);
  //         that.router.navigate(['/app/home']);
  //         console.log(data);
  //       }else if(successful && Utils.resultFailure(data.resultType)){
  //         const toastCfg = new ToastConfig(ToastType.WARNING, '', data.resultMsg, 3000);
  //         that.toastService.toast(toastCfg);
  //         console.log(data);
  //       }else{
  //         const toastCfg = new ToastConfig(ToastType.ERROR, '', data.resultMsg, 3000);
  //         that.toastService.toast(toastCfg);
  //         console.log(data);
  //       }
  //     }, function (successful, msg, err) {
  //        const toastCfg = new ToastConfig(ToastType.ERROR, '', msg, 3000);
  //        that.toastService.toast(toastCfg);
  //     });
  //
  //   }
  //
  //   const toastCfg = new ToastConfig(ToastType.SUCCESS, '', '登录成功！', 3000);
  //   this.toastService.toast(toastCfg);
  //   this.router.navigate(['/app/home']);
  // }
  login()
  {
    let that = this;
    if(this.stOrTa!='') {
      this.localStorage.set('stOrTa',this.stOrTa);
      this.localStorage.set('userName',this.loginForm.controls['userName'].value);
      that=this;
      console.log('选择了：' + this.stOrTa);
      let url = environment.domain+"/islogin/" +this.stOrTa+'/'+ this.loginForm.controls['userName'].value + '/' + this.loginForm.controls['password'].value;
      this.http.get(url).subscribe(
        function (data) {
          if (JSON.parse(data['_body']).flag == true) {
            // const toastCfg = new ToastConfig(ToastType.SUCCESS, '', data, 3000);
            // that.toastService.toast(toastCfg);
            that.router.navigate(['/app/home']);
            that.localStorage.set('userData',data['_body']);
            console.log(data);
            const toastCfg = new ToastConfig(ToastType.SUCCESS, '', '登陆成功', 3000);
            that.toastService.toast(toastCfg);
            console.log(JSON.parse(data['_body']).message);
          }else{
            const toastCfg = new ToastConfig(ToastType.ERROR, '', '用户类型错误或密码错误', 3000);
            that.toastService.toast(toastCfg);
            console.log('失败');
          }
        },
        function (err) {
          const toastCfg = new ToastConfig(ToastType.ERROR, '', '密码错误', 3000);
          that.toastService.toast(toastCfg);
          console.log('失败');
        });
    }else{
      const toastCfg = new ToastConfig(ToastType.ERROR, '', '请选择用户类型', 3000);
      that.toastService.toast(toastCfg);
      console.log('没有选择用户类型');
    }

    // this.http.post('http://www.corley.cn/api/v1/student/170327096',JSON.stringify({password: '123456'}), {headers:this.headers}).subscribe(
    //                 function(res){
    //                 console.log(res.json());
    //                 });

    // this.jsonp.get("http://www.corley.cn/api/v1/student/170327096?password=123456&callback=JSONP_CALLBACK")
    //  .subscribe(
    //  function(data)
    //  {
    //   console.log(data)
    //  });
  }
  reset(){
      this.router.navigate(['/login/register']);
  }
}
