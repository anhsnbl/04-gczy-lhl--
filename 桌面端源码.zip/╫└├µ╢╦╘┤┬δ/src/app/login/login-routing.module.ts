import { NgModule, OnInit } from '@angular/core';
import { RouterModule, Routes, Router } from '@angular/router';

import { LoginComponent }   from './login.component';
import {PasswordEditComponent} from "../business-shared/user/password-edit/password-edit.component";
import {RegisterComponent} from "../register/register.component";


/**
 * 主体路由
 */
const loginRoutes: Routes = [
  {
    path: '',
    component: LoginComponent
  },
  { path: 'register',
    component: RegisterComponent
  }
];

@NgModule({
  imports: [
    RouterModule.forChild(loginRoutes)
  ],
  exports: [
    RouterModule
  ]
})
export class LoginRoutingModule { }
