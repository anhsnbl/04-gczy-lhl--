import { Component, Input, ViewEncapsulation, ViewChild } from '@angular/core';
import {Validators,FormControl,FormGroup,FormBuilder} from '@angular/forms';
import { NgbActiveModal } from '@ng-bootstrap/ng-bootstrap';

import { ToastService } from '../../../shared/toast/toast.service';
import { ToastConfig, ToastType } from '../../../shared/toast/toast-model';
import { CustomValidators } from '../../../shared/custom-validator/custom-validator'
import {Http} from "@angular/http";
import {environment} from "../../../../environments/environment";
import {LocalStorageService} from "../../../shared/storage/local-storage.service";

/**
 * 修改密码组件
 */
@Component({
    selector: 'c-password-edit',
    templateUrl: './password-edit.component.html',
    encapsulation: ViewEncapsulation.None
})
export class PasswordEditComponent {

    passwordEditForm: FormGroup;


    constructor(public activeModal: NgbActiveModal,
                private toastService: ToastService,
                private formBuilder: FormBuilder,
                private localStorage: LocalStorageService,
                private http:Http) {
        let oldPasswordFc = new FormControl('', Validators.compose([Validators.required, Validators.minLength(6),Validators.maxLength(15)]));
        let passwordFc = new FormControl('', Validators.compose([Validators.required, Validators.minLength(6),Validators.maxLength(15)]));
        let certainPasswordFc  = new FormControl('',CustomValidators.equalTo(passwordFc));

        this.passwordEditForm=this.formBuilder.group({
            oldPassword:oldPasswordFc,
            password:passwordFc,
            certainPassword:certainPasswordFc
        });
    }

    /**
     * 上传
     */
    ok(): void {
      let that = this;
      let data = this.localStorage.get('userData');
      let isStOrTe = this.localStorage.get('stOrTa');
      let userName = this.localStorage.get('userName');
        if(this.passwordEditForm.valid){
             console.info(this.passwordEditForm.value);

          let url = environment.domain + 'setting/password/' + isStOrTe + '/' + userName+'/'+that.passwordEditForm.controls['oldPassword'].value+
          '/'+that.passwordEditForm.controls['password'].value;//该用户所有课程
          this.http.get(url).subscribe(
            function (data) {
              if (JSON.parse(data['_body']).flag == true) {
                const toastCfg = new ToastConfig(ToastType.SUCCESS, '', '修改密码成功!', 2000);
                that.toastService.toast(toastCfg);
                that.close();
              } else {
                const toastCfg = new ToastConfig(ToastType.ERROR, '', '没有课程', 3000);
                that.toastService.toast(toastCfg);
                console.log(JSON.parse(data['_body']).message);
              }
            },
            function (err) {
              const toastCfg = new ToastConfig(ToastType.ERROR, '', '没有课程', 3000);
              that.toastService.toast(toastCfg);
              console.log('失败');
            });
        }
    }

    /**
       * 关闭
       */
    close(): void {
        this.activeModal.dismiss({ status: 'closed' });
    }


}
