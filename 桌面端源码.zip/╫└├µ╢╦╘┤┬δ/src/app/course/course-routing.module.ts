import { NgModule }   from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import {CourseComponent} from "./course.component";
import {CoursedetailComponent} from "./coursedetail/coursedetail.component";
import {CoursearrangeComponent} from "./coursearrange/coursearrange.component";

const courseRoutes: Routes = [

  {
        path:'coursedetail',
        component:CoursedetailComponent
      },
      {
        path:'coursearrange',
        component:CoursearrangeComponent
      }
]


@NgModule({
  imports: [
    RouterModule.forChild(courseRoutes)
  ],
  exports: [
    RouterModule
  ]
})
export class CourseRoutingModule { }
