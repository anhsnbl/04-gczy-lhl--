/**
 * 定义课程数据
 */
export class courseData {
  courseID:any;
  course:any;
  courseNO:any;
  teacherNO:any;
  classroom:any;
  week:any;
  start:any;
  end:any;
}
