import { Component, OnInit } from '@angular/core';
import {LocalStorageService} from "../../shared/storage/local-storage.service";
import {Http, Jsonp} from "@angular/http";
import {ToastService} from "../../shared/toast/toast.service";
import {ToastConfig, ToastType} from "../../shared/toast/toast-model";
import {environment} from "../../../environments/environment";
import {courseData} from "./coursedetail-model";

@Component({
  selector: 'app-coursedetail',
  templateUrl: './coursedetail.component.html',
  styleUrls: ['./coursedetail.component.scss']
})
export class CoursedetailComponent implements OnInit {
  showList:Array<courseData>=[];
  dataList:Array<courseData>=[];
  pageNumber=1;//第几页
  pageTotal:any;//共几页
  objArr:Array<any>=[];
  totalData:string;
  nowSite=1;
  constructor(private localStorage: LocalStorageService,
              private http:Http,
              private toastService: ToastService) {
    this.addData();
  }

  tranData(){
    let i=0,j=0;
    let objArr=JSON.parse(this.totalData);
    for (;i<objArr.length;i++) {
      console.log(objArr[i]);
      this.dataList[i]=objArr[i];
      // this.dataList[i].courseID = objArr[i].courseID;
      // this.dataList[i].course = objArr[i].course;
      // this.dataList[i].courseNO = objArr[i].courseNO;
      // this.dataList[i].teacherNO = objArr[i].teacherNO;
      // this.dataList[i].classroom = objArr[i].classroom;
      // this.dataList[i].week = objArr[i].week;
      // this.dataList[i].start = objArr[i].start;
      // this.dataList[i].end = objArr[i].end;
    }
  }
  addData() {
    let that = this;
    let data = this.localStorage.get('userData');
    let isStOrTe = this.localStorage.get('stOrTa');
    let url = environment.domain + '/list/course/' + isStOrTe + '/' + JSON.parse(data).roleNO;
    this.http.get(url).subscribe(
      function (data) {
        if (JSON.parse(data['_body']).flag == true) {
          // const toastCfg = new ToastConfig(ToastType.SUCCESS, '', data, 3000);
          // that.toastService.toast(toastCfg);
          let a = data['_body'].toString();
          let cData = a.substring(parseInt(a.indexOf('[')),parseInt(a.indexOf(']')+1));
          console.log('该教师的课程：' +cData);
          //转换json
          let jsonArr = '[{"courseID":1,"course":"计算机工程实训","courseNO":"C170327001","teacherNO":"T170327001","classroom":"数计中-307","week":2,"start":"23:30","end":"23:50","period":"1-11"}]';
          that.totalData = cData;
          that.tranData();
          that.countPage();
        } else {
          const toastCfg = new ToastConfig(ToastType.ERROR, '', '没有课程', 3000);
          that.toastService.toast(toastCfg);
          console.log(JSON.parse(data['_body']).message);
        }
      },
      function (err) {
        const toastCfg = new ToastConfig(ToastType.ERROR, '', '没有课程', 3000);
        that.toastService.toast(toastCfg);
        console.log('失败');
      });
    //
// this.http.post(url,JSON.stringify({password: '123456'})).subscribe(
//                     function(res){
//                     console.log('post的方法'+res.json().list);
//                     });;
//   }
  }

  countPage(){
    console.log('dataList长度:'+this.dataList.length);
    if(this.dataList.length%15==0){
      this.pageTotal=this.dataList.length/15;
    }else{
      this.pageTotal=Math.trunc(this.dataList.length/15)+1;
    }
    for (let i = 0; i < this.dataList.length; i ++) {
      if(i>=(this.pageNumber-1)*15 && i<this.pageNumber*15)
      {
        this.showList[i] = this.dataList[i]; // 1, "string", false
      }
    }
  }
  back(){
    this.pageNumber--;
    this.showList=[];
    let j=0;
    for (let i = 0; i < this.dataList.length; i ++) {
      if(i>=(this.pageNumber-1)*15 && i<this.pageNumber*15)
      {
        this.showList[j] = this.dataList[i]; // 1, "string", false
        j++;
      }
    }
    this.nowSite=(this.pageNumber-1)*15;
  }
  next(){
    this.pageNumber++;
    this.showList=[];
    let j=0;
    for (let i = 0; i < this.dataList.length; i ++) {
      if(i>=(this.pageNumber-1)*15 && i<this.pageNumber*15)
      {
        this.showList[j] = this.dataList[i]; // 1, "string", false
        j++;
      }
    }
    this.nowSite=this.pageNumber*15;
  }
  ngOnInit() {
  }

}
