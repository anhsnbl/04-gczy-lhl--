
import {NgModule} from "@angular/core";
import {CourseRoutingModule} from "./course-routing.module";
import {CoursearrangeComponent} from "./coursearrange/coursearrange.component";
import {CoursedetailComponent} from "./coursedetail/coursedetail.component";
import {CourseComponent} from "./course.component";
import {FormsModule, ReactiveFormsModule} from "@angular/forms";
import {CommonModule} from "@angular/common";
import {ConnectionBackend, Jsonp} from "@angular/http";
import {PaginationModule} from "../shared/pagination/pagination.module";

@NgModule({
  imports: [
    CommonModule,
    CourseRoutingModule,
    ReactiveFormsModule,
    FormsModule,
    PaginationModule
  ],
  declarations: [
    CourseComponent,
    CoursearrangeComponent,
    CoursedetailComponent
  ],
  exports: [
  ],
  providers: [
  ]
})
export class CourseModule { }
