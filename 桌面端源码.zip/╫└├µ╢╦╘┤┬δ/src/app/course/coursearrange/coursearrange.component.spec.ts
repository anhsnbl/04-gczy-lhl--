import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { CoursearrangeComponent } from './coursearrange.component';

describe('CoursearrangeComponent', () => {
  let component: CoursearrangeComponent;
  let fixture: ComponentFixture<CoursearrangeComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ CoursearrangeComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(CoursearrangeComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
