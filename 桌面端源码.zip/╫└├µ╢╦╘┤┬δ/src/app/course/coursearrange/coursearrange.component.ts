import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-coursearrange',
  templateUrl: './coursearrange.component.html',
  styleUrls: ['./coursearrange.component.scss']
})
export class CoursearrangeComponent implements OnInit {
  leaders= [{'id':'1',name:'人工智能'},
    {'id':'2',name:'工程训练'},
    {'id':'3',name:'大数据'},]
  constructor() { }

  ngOnInit() {
  }
  getChange(uid: string) {
    console.log('=========');
    console.log(uid);
  }
}
