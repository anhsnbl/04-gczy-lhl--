package com.group.attence.dao;

import javax.persistence.Table;

import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.CrudRepository;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import com.group.attence.entity.Course;

@Repository
@Table(name = "course")
@Qualifier("courseRepository")
public interface CourseRepository extends CrudRepository<Course, Integer>{

//	public Course findOne(Integer id);
//	public Course save(Course c);
//	public void delete(Integer id);
//	public void delete(Course c);
//	public boolean exists(Integer id);
//	public Iterable<Course> findAll();
	@Query("select c from Course c where c.courseNO=:courseNO")
	public Course findCourseByNO(@Param("courseNO") String courseNO);
	@Query("select count(c) from Course c where c.courseNO=:courseNO")
	public int findCourseNumByNO(@Param("courseNO") String courseNO);
	
	@Query("select c from Course c where c.teacherNO=:teacherNO")
	public Iterable<Course> findCourseByTeacherNO(@Param("teacherNO") String teacherNO);
	@Query("select count(c) from Course c where c.teacherNO=:teacherNO")
	public int findCourseNumByTeacherNO(@Param("teacherNO") String teacherNO);
	
}
