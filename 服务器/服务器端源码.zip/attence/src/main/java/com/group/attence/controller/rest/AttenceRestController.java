package com.group.attence.controller.rest;

import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.group.attence.dao.AttenceRecordRepository;
import com.group.attence.dao.CourseRecordRepository;
import com.group.attence.dao.CourseRepository;
import com.group.attence.dao.StudentRepository;
import com.group.attence.entity.AttenceRecord;
import com.group.attence.entity.Course;
import com.group.attence.entity.EntityMessage;
import com.group.attence.entity.Message;
import com.group.attence.entity.Student;
import com.group.attence.entity.StudentAttence;

@RestController
public class AttenceRestController {

	@Autowired
	private CourseRepository courseRepository;
	@Autowired
	private AttenceRecordRepository attenceRecordRepository;
	@Autowired
	private StudentRepository studentRepository;
	
	/**
	 * 签到接口
	 * @param studentNO
	 * @param courseNO
	 * @return
	 */
	@RequestMapping("/attence/{studentNO}/{courseNO}")
	public Message attend(@PathVariable("studentNO") String studentNO, @PathVariable("courseNO") String courseNO) {
		
		Message msg = new Message();
		msg.setRoleID(2);
		msg.setRoleNO(studentNO);
		msg.setFlag(false);
		/**
		 * 生成记录对象
		 */
		AttenceRecord record = new AttenceRecord();
		long time = System.currentTimeMillis();
		record.setStudentNO(studentNO);
		record.setCourseNO(courseNO);
		record.setTime(time);
		/**
		 * 验证签到时间是否超时
		 */
		Calendar current = Calendar.getInstance();
		int week = current.get(Calendar.DAY_OF_WEEK) - 1; //星期日：0，星期一：1，星期二：2， 星期三3，星期四：4，星期五：5，星期六：6
		Date date =new Date();
		SimpleDateFormat sdf =new SimpleDateFormat("HH:mm");
		String currentTime = sdf.format(date);
		
		Course course = courseRepository.findCourseByNO(courseNO);
		System.out.println(currentTime + "  " + course.getStart() + "  " + course.getEnd());
		if(week != course.getWeek()) {
			msg.setMessage("该课程不在今天");
			return msg;
		}
		if((0 > currentTime.compareTo(course.getStart())) || (0 < currentTime.compareTo(course.getEnd()))) {
			msg.setMessage("不在签到时间范围，稍后重试");
			return msg;
		}
		attenceRecordRepository.save(record);
		msg.setFlag(true);
		msg.setMessage("签到成功");
		return msg;
	}
	/**
	 * 查询签到情况接口，按课程NO查找
	 * @return
	 */
	@RequestMapping("/list/course/attence/{courseNO}")
	public EntityMessage<StudentAttence> listAttenceByCourse(@PathVariable("courseNO") String courseNO) {
		
		EntityMessage<StudentAttence> msg = new EntityMessage<StudentAttence>();
		msg.setFlag(false);
		List<StudentAttence> studentAttences = null;
		Iterable<AttenceRecord> it = null;
		Iterator<AttenceRecord> itor = null;
		Course course = null;
		Map<String, Integer> map = new HashMap<String, Integer>();
		/**
		 * 查询课程信息
		 */
		int courseNum = courseRepository.findCourseNumByNO(courseNO);
		if(courseNum == 0) {
			msg.setMessage("该课程不存在");
			return msg;
		}
		/**
		 * 查询签到记录
		 */
		int recordNum = attenceRecordRepository.findAttenceRecordNumByNO(courseNO);
		if(recordNum == 0) {
			msg.setMessage("暂无学生签到记录");
			return msg;
		}
		/**
		 * 计算每位学生的签到次数
		 */
		it = attenceRecordRepository.findAttenceRecordByNO(courseNO);
		itor = it.iterator();
		while(itor.hasNext()) {
			AttenceRecord attenceRecord = itor.next();
			String studentNO = attenceRecord.getStudentNO();
			if(!map.containsKey(studentNO)) {
				map.put(studentNO, 1);
			} else {
				int num = map.get(studentNO);
				map.replace(studentNO, num + 1);
			}
		}
		/**
		 * 生成学生的所有课程签到记录
		 */
		course = courseRepository.findCourseByNO(courseNO);
		studentAttences = new ArrayList<StudentAttence>();
		for(String studentNO: map.keySet()) {
			int studentNum = studentRepository.findStudentNumByNO(studentNO);
			if(studentNum > 0) {
				Student student = studentRepository.findStudentByNO(studentNO);
				StudentAttence studentAttence = new StudentAttence();
//				studentAttence.setStudent(student);
//				studentAttence.setCourse(course);
//				studentAttence.setNum(map.get(studentNO));
				studentAttence.init(student, course, map.get(studentNO));
				studentAttences.add(studentAttence);
			}
		}
		msg.setFlag(true);
		msg.setMessage("查询成功");
		msg.setList(studentAttences);
		return msg;
	}
	/**
	 * 查询签到情况接口，按学生学号查找
	 * @return
	 */
	@RequestMapping("/list/student/attence/{studentNO}")
	public EntityMessage<StudentAttence> getStudentAttenceInfo(@PathVariable("studentNO")String studentNO) {
		
		EntityMessage<StudentAttence> msg = new EntityMessage<StudentAttence>();
		msg.setFlag(false);
		List<StudentAttence> studentAttences = null;
		Iterable<AttenceRecord> it = null;
		Iterator<AttenceRecord> itor = null;
		Student student = null;
		Map<String, Integer> map = new HashMap<String, Integer>();
		
		/**
		 * 查询学生信息
		 */
		int studentNum = studentRepository.findStudentNumByNO(studentNO);
		if(studentNum == 0) {
			msg.setMessage("该学生不存在");
			return msg;
		}
		/**
		 * 查询签到记录
		 */
		int recordNum = attenceRecordRepository.findAttenceRecordNumByStudentNO(studentNO);
		if(recordNum == 0) {
			msg.setMessage("暂无课程签到记录");
			return msg;
		}
		/**
		 * 计算每一门课程的签到次数
		 */
		it = attenceRecordRepository.findAttenceRecordByStudentNO(studentNO);
		itor = it.iterator();
		while(itor.hasNext()) {
			AttenceRecord attenceRecord = itor.next();
			String courseNO = attenceRecord.getCourseNO();
			if(!map.containsKey(courseNO)) {
				map.put(courseNO, 1);
			} else {
				int num = map.get(courseNO);
				map.replace(courseNO, num + 1);
			}
		}
		/**
		 * 生成学生的所有课程签到记录
		 */
		student = studentRepository.findStudentByNO(studentNO);
		studentAttences = new ArrayList<StudentAttence>();
		for(String courseNO: map.keySet()) {
			int courseNum = courseRepository.findCourseNumByNO(courseNO);
			if(courseNum > 0) {
				Course course = courseRepository.findCourseByNO(courseNO);
				StudentAttence studentAttence = new StudentAttence();
//				studentAttence.setStudent(student);
//				studentAttence.setCourse(course);
//				studentAttence.setNum(map.get(courseNO));
				studentAttence.init(student, course, map.get(courseNO));
				studentAttences.add(studentAttence);
			}
		}
		msg.setFlag(true);
		msg.setMessage("查询成功");
		msg.setList(studentAttences);
		return msg;
	}
	
}
