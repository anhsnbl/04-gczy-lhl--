package com.group.attence.entity;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name = "role_menu")
public class RoleMenu {

	@Id
	@GeneratedValue(strategy = GenerationType.AUTO)
	private Integer menuID;
	private int roleID;
	private String menu;
	private String url;
	
	public RoleMenu() {}
	public RoleMenu(int roleID, String menu, String url) {
		this.roleID = roleID;
		this.menu = menu;
		this.url = url;
	}
	
	public Integer getMenuID() {
		return menuID;
	}
	public void setMenuID(Integer menuID) {
		this.menuID = menuID;
	}
	public int getRoleID() {
		return roleID;
	}
	public void setRoleID(int roleID) {
		this.roleID = roleID;
	}
	public String getMenu() {
		return menu;
	}
	public void setMenu(String menu) {
		this.menu = menu;
	}
	public String getUrl() {
		return url;
	}
	public void setUrl(String url) {
		this.url = url;
	}
	
}
