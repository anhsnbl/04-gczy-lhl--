package com.group.attence.dao;

import javax.persistence.Table;

import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.CrudRepository;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import com.group.attence.entity.RoleMenu;

@Repository
@Table(name = "role_menu")
@Qualifier("roleMenuRepository")
public interface RoleMenuRepository extends CrudRepository<RoleMenu, Integer>{

	@Query("select r from RoleMenu r where r.roleID=:roleID")
	public RoleMenu findRoleMenuByName(@Param("roleID") int roleID);
	@Query("select count(r) from RoleMenu r where r.roleID=:roleID")
	public int findRoleMenuNumByName(@Param("roleID") int roleID);
	
}