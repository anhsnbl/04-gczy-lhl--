package com.group.attence.entity;

public class StudentAttence {

//	private Student student;
	private String studentNO;
	private String name;
	private String institute;
	private String major;
//	private Course course;
	private String courseNO;
	private String courseName;
	private String classroom;
	private int week;
	private String start;
	private String end;
	private String period;
	private int num;
	
	public StudentAttence() {}
	
	public void init(Student s, Course c, int num) {
		this.studentNO = s.getStudentNO();
		this.name = s.getName();
		this.institute = s.getInstitute();
		this.major = s.getMajor();
		
		this.courseNO = c.getCourseNO();
		this.courseName = c.getCourse();
		this.classroom = c.getClassroom();
		this.week = c.getWeek();
		this.start = c.getStart();
		this.end = c.getEnd();
		this.period = c.getPeriod();
		this.num = num;
	}
	
	public String getStudentNO() {
		return studentNO;
	}
	public void setStudentNO(String studentNO) {
		this.studentNO = studentNO;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public String getInstitute() {
		return institute;
	}
	public void setInstitute(String institute) {
		this.institute = institute;
	}
	public String getMajor() {
		return major;
	}
	public void setMajor(String major) {
		this.major = major;
	}
	public String getCourseNO() {
		return courseNO;
	}
	public void setCourseNO(String courseNO) {
		this.courseNO = courseNO;
	}
	public String getCourseName() {
		return courseName;
	}
	public void setCourseName(String courseName) {
		this.courseName = courseName;
	}
	public String getClassroom() {
		return classroom;
	}
	public void setClassroom(String classroom) {
		this.classroom = classroom;
	}
	public int getWeek() {
		return week;
	}
	public void setWeek(int week) {
		this.week = week;
	}
	public String getStart() {
		return start;
	}
	public void setStart(String start) {
		this.start = start;
	}
	public String getEnd() {
		return end;
	}
	public void setEnd(String end) {
		this.end = end;
	}
	public String getPeriod() {
		return period;
	}
	public void setPeriod(String period) {
		this.period = period;
	}
	public int getNum() {
		return num;
	}
	public void setNum(int num) {
		this.num = num;
	}
	
}
