package com.group.attence.controller;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;

//@RestController
@Controller
@RequestMapping("/attence")
public class CommonController {

	@RequestMapping("/index")
	public String index() {
		return "/pages/login.html";
	}
	@RequestMapping("/admin")
	public String adminGate() {
		String url = "/pages/index.html";
		return url;
	}
	
}
