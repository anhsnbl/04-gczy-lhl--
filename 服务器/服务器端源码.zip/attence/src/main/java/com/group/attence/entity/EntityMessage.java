package com.group.attence.entity;

import java.util.List;

public class EntityMessage<T> {

	private boolean flag;
	private String message;
	private List<T> list;
	
	public EntityMessage() {}
	public EntityMessage(boolean flag, List<T> list, String message) {
		super();
		this.flag = flag;
		this.list = list;
		this.message = message;
	}
	public EntityMessage(Message message) {
		super();
		this.flag = message.getFlag();
		this.message = message.getMessage();
	}
	
	public boolean isFlag() {
		return flag;
	}
	public void setFlag(boolean flag) {
		this.flag = flag;
	}
	public List<T> getList() {
		return list;
	}
	public void setList(List<T> list) {
		this.list = list;
	}
	public String getMessage() {
		return message;
	}
	public void setMessage(String message) {
		this.message = message;
	}
	
}
