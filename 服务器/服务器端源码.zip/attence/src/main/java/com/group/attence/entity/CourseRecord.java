package com.group.attence.entity;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name = "record_course")
public class CourseRecord {

	@Id
	@GeneratedValue(strategy = GenerationType.AUTO)
	private Integer recordID;
	private String studentNO;
	private String courseNO;
	
	public CourseRecord() {}
	public CourseRecord(String studentNO, String courseNO) {
		super();
		this.studentNO = studentNO;
		this.courseNO = courseNO;
	}
	
	public Integer getRecordID() {
		return recordID;
	}
	public void setRecordID(Integer recordID) {
		this.recordID = recordID;
	}
	public String getStudentNO() {
		return studentNO;
	}
	public void setStudentNO(String studentNO) {
		this.studentNO = studentNO;
	}
	public String getCourseNO() {
		return courseNO;
	}
	public void setCourseNO(String courseNO) {
		this.courseNO = courseNO;
	}
	
}
