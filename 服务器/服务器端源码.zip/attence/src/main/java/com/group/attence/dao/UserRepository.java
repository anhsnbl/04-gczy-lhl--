package com.group.attence.dao;

import javax.persistence.Table;

import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.CrudRepository;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import com.group.attence.entity.User;

@Repository
@Table(name = "user")
@Qualifier("userRepository")
public interface UserRepository extends CrudRepository<User, Integer>{

//	public User findOne(Integer id);
//	public User save(User u);
//	public void delete(Integer id);
//	public void delete(User u);
//	public boolean exists(Integer id);
//	public Iterable<User> findAll();
	@Query("select u from User u where u.username=:username")
	public User findUserByName(@Param("username") String username);
	@Query("select count(u) from User u where u.username=:username")
	public int findUserNumByName(@Param("username") String username);
	@Query("select u from User u where u.roleNO=:roleNO")
	public User findUserByNO(@Param("roleNO") String roleNO);
	@Query("select count(u) from User u where u.roleNO=:roleNO")
	public int findUserNumByNO(@Param("roleNO") String roleNO);
	@Query("select u from User u where u.roleID>0")
	public Iterable<User> findAllByRoleID();
	
}
