package com.group.attence.dao;

import javax.persistence.Table;

import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.CrudRepository;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import com.group.attence.entity.Course;
import com.group.attence.entity.CourseRecord;

@Repository
@Table(name = "record_course")
@Qualifier("courseRecordRepository")
public interface CourseRecordRepository extends CrudRepository<CourseRecord, Integer>{

//	public CourseRecord findOne(Integer id);
//	public CourseRecord save(CourseRecord c);
//	public void delete(Integer id);
//	public void delete(CourseRecord c);
//	public boolean exists(Integer id);
//	public Iterable<CourseRecord> findAll();
	@Query("select c from CourseRecord c where c.courseNO=:courseNO")
	public Iterable<CourseRecord> findCourseByNO(@Param("courseNO") String courseNO);
	@Query("select count(c) from CourseRecord c where c.courseNO=:courseNO")
	public int findCourseNumByNO(@Param("courseNO") String courseNO);
	
	@Query("select c from CourseRecord c where c.studentNO=:studentNO")
	public Iterable<CourseRecord> findCourseByStudentNO(@Param("studentNO") String studentNO);
	@Query("select count(c) from CourseRecord c where c.studentNO=:studentNO")
	public int findCourseNumByStudentNO(@Param("studentNO") String studentNO);
	
}
