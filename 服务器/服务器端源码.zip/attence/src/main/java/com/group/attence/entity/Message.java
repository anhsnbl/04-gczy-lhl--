package com.group.attence.entity;

public class Message {

	private boolean flag;
	private int roleID;
	private String roleNO;
	private String message;
	private Person user;
	
	public Message() {}
	public Message(boolean flag, String message) {
		super();
		this.flag = flag;
		this.message = message;
	}
	
	public boolean getFlag() {
		return flag;
	}
	public void setFlag(boolean flag) {
		this.flag = flag;
	}
	public String getMessage() {
		return message;
	}
	public void setMessage(String message) {
		this.message = message;
	}
	public int getRoleID() {
		return roleID;
	}
	public void setRoleID(int roleID) {
		this.roleID = roleID;
	}
	public String getRoleNO() {
		return roleNO;
	}
	public void setRoleNO(String roleNO) {
		this.roleNO = roleNO;
	}
	public Person getUser() {
		return user;
	}
	public void setUser(Person user) {
		this.user = user;
	}
	
}
