package com.group.attence.entity;

import java.util.Date;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name = "record_attence")
public class AttenceRecord {

	@Id
	@GeneratedValue(strategy = GenerationType.AUTO)
	private Integer recordID;
	private String studentNO;
	private String courseNO;
	private long time;
	
	public AttenceRecord() {}
	public AttenceRecord(String studentNO, String courseNO, long time) {
		super();
		this.studentNO = studentNO;
		this.courseNO = courseNO;
		this.time = time;
	}

	public Integer getRecordID() {
		return recordID;
	}
	public void setRecordID(Integer recordID) {
		this.recordID = recordID;
	}
	public String getStudentNO() {
		return studentNO;
	}
	public void setStudentNO(String studentNO) {
		this.studentNO = studentNO;
	}
	public String getCourseNO() {
		return courseNO;
	}
	public void setCourseNO(String courseNO) {
		this.courseNO = courseNO;
	}
	public long getTime() {
		return time;
	}
	public void setTime(long time) {
		this.time = time;
	}
	
}
