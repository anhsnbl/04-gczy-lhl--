package com.group.attence.entity;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name = "teacher")
public class Teacher {

	@Id
	@GeneratedValue(strategy = GenerationType.AUTO)
	private Integer teacherID;
	private String teacherNO;
	private String name;
	private String gender;
	private String institute;
	
	public Teacher() {}
	public Teacher(String teacherNO, String name, String gender, String institute) {
		super();
		this.teacherNO = teacherNO;
		this.name = name;
		this.gender = gender;
		this.institute = institute;
	}
	
	public Integer getTeacherID() {
		return teacherID;
	}
	public void setTeacherID(Integer teacherID) {
		this.teacherID = teacherID;
	}
	public String getTeacherNO() {
		return teacherNO;
	}
	public void setTeacherNO(String teacherNO) {
		this.teacherNO = teacherNO;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public String getGender() {
		return gender;
	}
	public void setGender(String gender) {
		this.gender = gender;
	}
	public String getInstitute() {
		return institute;
	}
	public void setInstitute(String institute) {
		this.institute = institute;
	}
	
}
