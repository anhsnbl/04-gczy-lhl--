package com.group.attence.entity;

public class CourseMessage {

	private boolean flag;
	private String courseNO;
	private String message;
	private Course course;
	
	public CourseMessage() {}
	public CourseMessage(boolean flag, String courseNO, String message, Course course) {
		super();
		this.flag = flag;
		this.courseNO = courseNO;
		this.message = message;
		this.course = course;
	}
	
	public boolean isFlag() {
		return flag;
	}
	public void setFlag(boolean flag) {
		this.flag = flag;
	}
	public String getCourseNO() {
		return courseNO;
	}
	public void setCourseNO(String courseNO) {
		this.courseNO = courseNO;
	}
	public String getMessage() {
		return message;
	}
	public void setMessage(String message) {
		this.message = message;
	}
	public Course getCourse() {
		return course;
	}
	public void setCourse(Course course) {
		this.course = course;
	}
	
}
