package com.group.attence.entity;

import java.util.List;

public class AttenceMessage {

	private boolean flag;
	private String message;
	private Course course;
	private List<StudentAttence> attences;
	
	public AttenceMessage() {}
	public AttenceMessage(boolean flag, String message, Course course, List<StudentAttence> attences) {
		super();
		this.flag = flag;
		this.message = message;
		this.course = course;
		this.attences = attences;
	}

	public boolean isFlag() {
		return flag;
	}
	public void setFlag(boolean flag) {
		this.flag = flag;
	}
	public String getMessage() {
		return message;
	}
	public void setMessage(String message) {
		this.message = message;
	}
	public Course getCourse() {
		return course;
	}
	public void setCourse(Course course) {
		this.course = course;
	}
	public List<StudentAttence> getAttences() {
		return attences;
	}
	public void setAttences(List<StudentAttence> attences) {
		this.attences = attences;
	}
	
}
