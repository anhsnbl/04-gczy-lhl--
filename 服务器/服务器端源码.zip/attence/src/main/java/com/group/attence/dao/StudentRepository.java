package com.group.attence.dao;

import javax.persistence.Table;

import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.CrudRepository;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import com.group.attence.entity.Student;

@Repository
@Table(name = "student")
@Qualifier("studentRepository")
public interface StudentRepository extends CrudRepository<Student, Integer>{

//	public Student findOne(Integer id);
//	public Student save(Student u);
//	public void delete(Integer id);
//	public void delete(Student u);
//	public boolean exists(Integer id);
//	public Iterable<Student> findAll();
	@Query("select s from Student s where s.studentNO=:studentNO")
	public Student findStudentByNO(@Param("studentNO") String studentNO);
	@Query("select count(s) from Student s where s.studentNO=:studentNO")
	public int findStudentNumByNO(@Param("studentNO") String studentNO);
	
}
