package com.group.attence.controller.rest;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.group.attence.dao.CourseRecordRepository;
import com.group.attence.dao.CourseRepository;
import com.group.attence.dao.StudentRepository;
import com.group.attence.entity.Course;
import com.group.attence.entity.CourseMessage;
import com.group.attence.entity.CourseRecord;
import com.group.attence.entity.EntityMessage;
import com.group.attence.entity.Message;
import com.group.attence.entity.Student;

@RestController
public class CourseRestController {

	@Autowired
	private CourseRepository courseRepository;
	@Autowired
	private CourseRecordRepository courseRecordRepository;
	@Autowired
	private StudentRepository studentRepository;
	
	/**
	 * 查询课程信息接口，按课程NO查找
	 * @param courseNO
	 * @return
	 */
	@RequestMapping("/info/course/{courseNO}")
	public CourseMessage getCourseInfo(@PathVariable("courseNO")String courseNO) {
		
		CourseMessage msg = new CourseMessage();
		msg.setFlag(false);
		msg.setCourseNO(courseNO);
		
		int num = courseRepository.findCourseNumByNO(courseNO);
		if(num == 0) {
			msg.setMessage("该课程不存在");
			return msg;
		}
		Course course = courseRepository.findCourseByNO(courseNO);
		msg.setCourse(course);
		msg.setFlag(true);
		msg.setMessage("查询成功");
		return msg;
	}
	/**
	 * 查询课程列表接口
	 * @param roleID
	 * @param roleNO
	 * @return
	 */
	@RequestMapping("/list/course/{roleID}/{roleNO}")
	public EntityMessage<Course> listCourse(@PathVariable("roleID") int roleID, @PathVariable("roleNO") String roleNO) {
		
		EntityMessage<Course> msg = new EntityMessage<Course>();
		List<Course> courses = null;
		Iterable<Course> it = null;
		Iterator<Course> itor = null;
		Iterable<CourseRecord> recordIt = null;
		Iterator<CourseRecord> recordItor = null;
		int courseNum = 0;
		
		if(roleID == 0) {
			courses = new ArrayList<Course>();
			it = courseRepository.findAll();
			itor = it.iterator();
			while(itor.hasNext()) {
				courses.add(itor.next());
			}
		} else if(roleID == 1) {
			courseNum = courseRepository.findCourseNumByTeacherNO(roleNO);
			if(courseNum > 0) {
				courses = new ArrayList<Course>();
				it = courseRepository.findCourseByTeacherNO(roleNO);
				itor = it.iterator();
				while (itor.hasNext()) {
					courses.add(itor.next());
				}
			}
		} else if(roleID == 2) {
			courseNum = courseRecordRepository.findCourseNumByStudentNO(roleNO);
			if(courseNum > 0) {
				courses = new ArrayList<Course>();
				recordIt = courseRecordRepository.findCourseByStudentNO(roleNO);
				recordItor = recordIt.iterator();
				while (recordItor.hasNext()) {
					String courseNO = recordItor.next().getCourseNO();
					Course course = courseRepository.findCourseByNO(courseNO);
					courses.add(course);
				}
			}
		}
		msg.setFlag(true);
		msg.setList(courses);
		msg.setMessage("查询成功");
		return msg;
	}
	/**
	 * 修改课程签到时间接口
	 * @param teacherNO
	 * @param courseNO
	 * @param startTime
	 * @param endTime
	 * @return
	 */
	@RequestMapping("/setting/course/{teacherNO}/{courseNO}/{startTime}/{endTime}")
	public Message updateTime(@PathVariable("teacherNO") String teacherNO, @PathVariable("courseNO") String courseNO
			, @PathVariable("startTime") String startTime, @PathVariable("endTime") String endTime) {
		
		Course course = courseRepository.findCourseByNO(courseNO);
		Message msg = new Message();
		
		if(!teacherNO.equals(course.getTeacherNO())) {
			msg.setFlag(false);
			msg.setMessage("没有权限修改该课程信息");
			return msg;
		}
		course.setStart(startTime);
		course.setEnd(endTime);
		courseRepository.save(course);
		msg.setFlag(true);
		msg.setMessage("修改成功");
		return msg;
	}
	/**
	 * 查询选课情况接口，按课程NO查找
	 * @param courseNO
	 * @return
	 */
	@RequestMapping("/list/course/student/{courseNO}")
	public EntityMessage<Student> listStudentByCourse(@PathVariable("courseNO") String courseNO) {
		
		EntityMessage<Student> msg = new EntityMessage<Student>();
		msg.setFlag(false);
		List<Student> students = null;
		Iterable<CourseRecord> it = null;
		Iterator<CourseRecord> itor = null;
		int recordNum = courseRecordRepository.findCourseNumByNO(courseNO);
		if(recordNum > 0) {
			it = courseRecordRepository.findCourseByNO(courseNO);
			itor = it.iterator();
			students = new ArrayList<Student>();
			while(itor.hasNext()) {
				CourseRecord cr = itor.next();
				Student stu = studentRepository.findStudentByNO(cr.getStudentNO());
				students.add(stu);
			}
			msg.setList(students);
			msg.setFlag(true);
			msg.setMessage("查询成功，共" + students.size() + "位学生选修该课程");
		} else {
			msg.setFlag(true);
			msg.setMessage("无该课程选修记录");
		}
		return msg;
	}
	
}
