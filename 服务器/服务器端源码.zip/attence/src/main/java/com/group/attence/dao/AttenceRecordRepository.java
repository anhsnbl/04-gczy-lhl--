package com.group.attence.dao;

import javax.persistence.Table;

import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.CrudRepository;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import com.group.attence.entity.AttenceRecord;
import com.group.attence.entity.CourseRecord;

@Repository
@Table(name = "record_attence")
@Qualifier("attenceRecordRepository")
public interface AttenceRecordRepository extends CrudRepository<AttenceRecord, Integer>{

//	public AttenceRecord findOne(Integer id);
//	public AttenceRecord save(AttenceRecord c);
//	public void delete(Integer id);
//	public void delete(AttenceRecord c);
//	public boolean exists(Integer id);
//	public Iterable<AttenceRecord> findAll();
	@Query("select a from AttenceRecord a where a.courseNO=:courseNO")
	public Iterable<AttenceRecord> findAttenceRecordByNO(@Param("courseNO") String courseNO);
	@Query("select count(a) from AttenceRecord a where a.courseNO=:courseNO")
	public int findAttenceRecordNumByNO(@Param("courseNO") String courseNO);
	
	@Query("select a from AttenceRecord a where a.studentNO=:studentNO")
	public Iterable<AttenceRecord> findAttenceRecordByStudentNO(@Param("studentNO") String studentNO);
	@Query("select count(a) from AttenceRecord a where a.studentNO=:studentNO")
	public int findAttenceRecordNumByStudentNO(@Param("studentNO") String studentNO);
	
}
