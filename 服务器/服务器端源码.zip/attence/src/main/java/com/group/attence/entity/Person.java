package com.group.attence.entity;

public class Person {

	private Integer id = null;
	private String no = null;
	private String name = null;
	private String gender = null;
	private String institute = null;
	private String major = null;
	private String telephone = null;
	
	public Person() {
		this.id = -1;
		this.no = "不详";
		this.name = "不详";
		this.gender = "不详";
		this.institute = "不详";
		this.major = "不详";
		this.telephone = "不详";
	}
	
	public void initPerson(Student s) {
		this.id = s.getStudentID();
		this.no = s.getStudentNO();
		this.name = s.getName();
		this.gender = s.getGender();
		this.institute = s.getInstitute();
		this.major = s.getMajor();
	}
	public void initPerson(Teacher t) {
		this.id = t.getTeacherID();
		this.no = t.getTeacherNO();
		this.name = t.getName();
		this.gender = t.getGender();
		this.institute = t.getInstitute();
	}
	
	public Integer getId() {
		return id;
	}
	public void setId(Integer id) {
		this.id = id;
	}
	public String getNo() {
		return no;
	}
	public void setNo(String no) {
		this.no = no;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public String getGender() {
		return gender;
	}
	public void setGender(String gender) {
		this.gender = gender;
	}
	public String getInstitute() {
		return institute;
	}
	public void setInstitute(String institute) {
		this.institute = institute;
	}
	public String getMajor() {
		return major;
	}
	public void setMajor(String major) {
		this.major = major;
	}
	public String getTelephone() {
		return telephone;
	}
	public void setTelephone(String telephone) {
		this.telephone = telephone;
	}
	
}
