package com.group.attence.controller.rest;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.group.attence.dao.StudentRepository;
import com.group.attence.dao.TeacherRepository;
import com.group.attence.dao.UserRepository;
import com.group.attence.entity.EntityMessage;
import com.group.attence.entity.Message;
import com.group.attence.entity.Person;
import com.group.attence.entity.Student;
import com.group.attence.entity.Teacher;
import com.group.attence.entity.User;

@RestController
public class UserRestController {

	@Autowired
	private UserRepository userRepository;
	@Autowired
	private StudentRepository studentRepository;
	@Autowired
	private TeacherRepository teacherRepository;
	
	@RequestMapping("/login/{username}/{passwd}")
	public User doLogin(@PathVariable("username") String username, @PathVariable("passwd") String passwd) {

		// User user = new User(username, passwd);
		int num = userRepository.findUserNumByName(username);
		if (num == 0) {
			Message msg = new Message();
			msg.setFlag(false);
			msg.setMessage("用户" + username + "不存在");
		}
		User user1 = userRepository.findUserByName(username);
		if (!passwd.equals(user1.getPasswd())) {
			Message msg = new Message();
			msg.setFlag(false);
			msg.setMessage("密码错误");
		}
		System.out.println(user1.getPasswd());
		return user1;
	}
	/**
	 * 用户登录接口
	 * @param roleID 角色ID，0为管理员，1为教师，2为学生
	 * @param username 用户名
	 * @param passwd 密码
	 * @return
	 */
	@RequestMapping("/islogin/{roleID}/{username}/{passwd}")
	public Message isLogin(@PathVariable("roleID") int roleID, @PathVariable("username") String username,
			@PathVariable("passwd") String passwd) {

		Message msg = new Message();
		msg.setFlag(false);
		
		int num = userRepository.findUserNumByName(username);
		/** 按用户名查找，不存在用户，登录失败 */
		if (num == 0) {
			msg.setMessage("用户" + username + "不存在");
			return msg;
		}
		User user = userRepository.findUserByName(username);
		/** 按用户名查找，用户角色不对，登录失败 */
		if (roleID != user.getRoleID()) {
			msg.setMessage("用户" + username + "不存在");
			return msg;
		}
		/** 按用户名查找，密码错误，登录失败 */
		if (!passwd.equals(user.getPasswd())) {
			msg.setMessage("密码错误");
			return msg;
		}
		/** 登录成功 */
		Person person = new Person();
		if(roleID == 0) {
			person.setName("管理员");
			person.setNo(user.getRoleNO());
		} else if(roleID == 1) {
			Teacher teacher = teacherRepository.findTeacherByNO(user.getRoleNO());
			person.initPerson(teacher);
		} else if(roleID == 2) {
			Student student = studentRepository.findStudentByNO(user.getRoleNO());
			person.initPerson(student);
		}
		StringBuffer sb = new StringBuffer();
		sb.append("用户");
		sb.append(username);
		sb.append("登录成功,用户ID为");
		sb.append(user.getUserID());
		/**
		 * 登录成功，返回路径中需要的信息：{角色}、{学号或工号}
		 */
		msg.setFlag(true);
		msg.setRoleID(roleID);
		msg.setRoleNO(user.getRoleNO());
		msg.setUser(person);
		msg.setMessage(sb.toString());
		return msg;
	}
	/**
	 * 修改密码接口
	 * @param roleID 角色ID，0为管理员，1为教师，2为学生
	 * @param username 用户名
	 * @param oldPasswd 旧密码
	 * @param passwd 新密码
	 * @return
	 */
	@RequestMapping("/setting/password/{roleID}/{username}/{oldPasswd}/{passwd}")
	public Message updatePassword(@PathVariable("roleID") int roleID, @PathVariable("username") String username,
			@PathVariable("oldPasswd") String oldPasswd, @PathVariable("passwd") String passwd) {
		
		Message msg = new Message();
		msg.setFlag(false);
		
		if(roleID != 1 && roleID != 2) {
			msg.setMessage("权限不足，无法创建该角色用户");
			return msg;
		}
		int num = userRepository.findUserNumByName(username);
		/** 按用户名查找，不存在用户，修改失败 */
		if (num == 0) {
			msg.setMessage("用户" + username + "不存在");
			return msg;
		}
		User user = userRepository.findUserByName(username);
		/** 按用户名查找，用户角色不对，修改失败 */
		if (roleID != user.getRoleID()) {
			msg.setMessage("用户" + username + "不存在");
			return msg;
		}
		/** 按用户名查找，密码错误，修改失败 */
		if (!oldPasswd.equals(user.getPasswd())) {
			msg.setMessage("密码错误");
			return msg;
		}
		/** 修改成功 */
		user.setPasswd(passwd);
		userRepository.save(user);
		
		msg.setFlag(true);
		StringBuffer sb = new StringBuffer();
		sb.append("修改成功");
		/**
		 * 返回路径中需要的信息：{角色}、{学号或工号}
		 */
		msg.setRoleID(roleID);
		msg.setRoleNO(user.getRoleNO());
		msg.setMessage(sb.toString());
		return msg;
	}
	@RequestMapping("/register/{roleID}/{username}/{passwd}/{telephone}")
	public Message register(@PathVariable("roleID") int roleID, @PathVariable("username") String username,
			@PathVariable("passwd") String passwd, @PathVariable("telephone") String telephone) {

		int num = userRepository.findUserNumByName(username);
		Message msg = new Message();
		msg.setFlag(false);

		/** 按用户名查找，存在同名用户，注册失败 */
		if (num > 0) {
			msg.setMessage("用户" + username + "已存在");
			return msg;
		}

		// User user = new User();
		// user.setUsername("郭鸿清");
		// user.setPasswd("123123");
		// user.setRoleID(1);
		// user.setTelephone("18605088347");
		// User result = userRepository.save(user);
		/** 注册成功 */
		User user = new User();
		user.setRoleID(roleID);
		user.setUsername(username);
		user.setPasswd(passwd);
		/** 可添加手机号验证功能 */
		user.setTelephone(telephone);
		/** 保存到数据库 */
		User result = userRepository.save(user);
		StringBuffer sb = new StringBuffer();
		sb.append("用户");
		sb.append(username);
		sb.append("注册成功,用户ID为");
		sb.append(result.getUserID());
		/** 返回消息 */
		msg.setFlag(true);
		msg.setMessage(sb.toString());
		return msg;
	}
	/**
	 * 用户注册接口
	 * @param roleID 角色ID，0为管理员，1为教师，2为学生
	 * @param username 用户名
	 * @param roleNO 角色编号，对应教师或学生学号
	 * @param passwd 密码
	 * @param telephone 手机号
	 * @param gender 性别
	 * @return
	 */
	@RequestMapping("/register/{roleID}/{username}/{roleNO}/{passwd}/{telephone}/{gender}")
	public Message register1(@PathVariable("roleID") int roleID, @PathVariable("username") String username,
			@PathVariable("roleNO") String roleNO, @PathVariable("passwd") String passwd,
			@PathVariable("telephone") String telephone, @PathVariable("gender") String gender) {

		Message msg = new Message();
		msg.setFlag(false);
		msg.setRoleID(roleID);
		msg.setRoleNO(roleNO);

		/** 按用户名查找，存在同名用户，注册失败 */
		int num = userRepository.findUserNumByName(username);
		if (num > 0) {
			msg.setMessage("用户" + username + "已存在");
			return msg;
		}
		/** 按学号/工号查找，一个用户只能对应一个学生或教师，注册失败 */
		num = userRepository.findUserNumByNO(roleNO);
		if (num > 0) {
			msg.setMessage("该学号/工号" + roleNO + "已绑定");
			return msg;
		}
		/** 按学号/工号查找，学号/工号对应角色不存在，注册失败 */
		int teaNum = 0;
		int stuNum = 0;
		if (roleID == 1) {
			teaNum = teacherRepository.findTeacherNumByNO(roleNO);
		} else if (roleID == 2) {
			stuNum = studentRepository.findStudentNumByNO(roleNO);
		} else {
			msg.setMessage("无法创建该角色用户");
			return msg;
		}
		if (teaNum == 0 && stuNum == 0) {
			msg.setMessage("该学号/工号" + roleNO + "不存在");
			return msg;
		}

		// User user = new User();
		// user.setUsername("郭鸿清");
		// user.setPasswd("123123");
		// user.setRoleID(1);
		// user.setTelephone("18605088347");
		// User result = userRepository.save(user);
		/** 注册成功 */
		User user = new User();
		user.setRoleID(roleID);
		user.setUsername(username);
		user.setPasswd(passwd);
		/** 可添加手机号验证功能 */
		user.setTelephone(telephone);
		user.setRoleNO(roleNO);
		/** 保存到数据库 */
		User result = userRepository.save(user);
		StringBuffer sb = new StringBuffer();
		sb.append("用户");
		sb.append(username);
		sb.append("注册成功,用户ID为");
		sb.append(result.getUserID());
		/** 返回消息 */
		msg.setFlag(true);
		msg.setMessage(sb.toString());
		return msg;
	}
	/**
	 * 查看用户信息接口
	 * @param roleID 角色ID，0为管理员，1为教师，2为学生
	 * @param roleNO 角色编号，对应教师或学生学号
	 * @return
	 */
	@RequestMapping("/info/user/{roleID}/{roleNO}")
	public Message getInfo(@PathVariable("roleID") int roleID, @PathVariable("roleNO") String roleNO) {

		Message msg = new Message();
		msg.setFlag(false);
		msg.setRoleID(roleID);
		msg.setRoleNO(roleNO);
		
		/**
		 * 按学号/工号查询用户
		 */
		User user = null;
		int userNum = userRepository.findUserNumByNO(roleNO);
		if(userNum > 0) {
			user = userRepository.findUserByNO(roleNO);
		}else {
			msg.setMessage("该用户不存在");
			return msg;
		}
		
		Person person = new Person();
		/** 按学号/工号查找，学号/工号对应角色不存在，查询失败 */
		int teaNum = 0;
		int stuNum = 0;
		if (roleID == 1) {
			teaNum = teacherRepository.findTeacherNumByNO(roleNO);
			if (teaNum > 0) {
				Teacher teacher = teacherRepository.findTeacherByNO(roleNO);
				person.initPerson(teacher);
			} else {
				msg.setMessage("该工号对应的教师不存在");
				return msg;
			}
		} else if (roleID == 2) {
			stuNum = studentRepository.findStudentNumByNO(roleNO);
			if (stuNum > 0) {
				Student student = studentRepository.findStudentByNO(roleNO);
				person.initPerson(student);
			} else {
				msg.setMessage("该学号对应的学生不存在");
				return msg;
			}
		} else {
			msg.setMessage("该角色用户不存在");
			return msg;
		}
		/**
		 * 设置用户手机号
		 */
		person.setTelephone(user.getTelephone());
		/**
		 * 查询成功，返回消息
		 */
		msg.setFlag(true);
		msg.setUser(person);
		msg.setMessage("查询成功");
		return msg;
	}

	/**
	 * 可以添加手机短信验证的接口，设计一张表，包含手机号，验证码（可以有时间，超时。。。）两个字段，自动生成验证码，发送短信
	 */

	/**
	 * 查询用户列表接口（管理员权限）
	 * @param roleID 角色ID，0为管理员，1为教师，2为学生
	 * @param roleNO 角色编号，对应教师或学生学号
	 * @return
	 */
	@RequestMapping("/list/user/{roleID}/{roleNO}")
	public EntityMessage<User> getAllUser(@PathVariable("roleID") int roleID, 
			@PathVariable("roleNO") String roleNO) {

		EntityMessage<User> msg = new EntityMessage<User>();
		msg.setFlag(false);
		List<User> users = null;
		Iterable<User> it = null;
		Iterator<User> itor = null;
		
		if (roleID > 0) {
			msg.setMessage("操作失败，权限不足");
			return msg;
		}
		/** 按学号/工号查找，学号/工号对应角色不存在 */
		int num = userRepository.findUserNumByNO(roleNO);
		if (num == 0) {
			msg.setMessage("操作失败，请先登录");
			return msg;
		}
		
		users = new ArrayList<User>();
		it = userRepository.findAllByRoleID();
		itor = it.iterator();
		while (itor.hasNext()) {
			users.add(itor.next());
		}
		msg.setList(users);
		msg.setFlag(true);
		msg.setMessage("操作成功");
		return msg;
	}
	/**
	 * 查询学生列表接口（管理员权限）
	 * @param roleID
	 * @param roleNO
	 * @return
	 */
	@RequestMapping("/list/student/{roleID}/{roleNO}")
	public EntityMessage<Student> getAllStudent(@PathVariable("roleID") int roleID, @PathVariable("roleNO") String roleNO) {
		
		EntityMessage<Student> msg = new EntityMessage<Student>();
		msg.setFlag(false);
		List<Student> students = null;
		Iterable<Student> it = null;
		Iterator<Student> itor = null;
		
		if (roleID > 0) {
			msg.setMessage("操作失败，权限不足");
			return msg;
		}
		/** 按学号/工号查找，学号/工号对应角色不存在 */
		int num = userRepository.findUserNumByNO(roleNO);
		if (num == 0) {
			msg.setMessage("操作失败，请先登录");
			return msg;
		}
		
		students = new ArrayList<Student>();
		it = studentRepository.findAll();
		itor = it.iterator();
		while (itor.hasNext()) {
			students.add(itor.next());
		}
		msg.setList(students);
		msg.setFlag(true);
		msg.setMessage("操作成功");
		return msg;
	}
	/**
	 * 查询教师列表接口（管理员权限）
	 * @param roleID
	 * @param roleNO
	 * @return
	 */
	@RequestMapping("/list/teacher/{roleID}/{roleNO}")
	public EntityMessage<Teacher> getAllTeacher(@PathVariable("roleID") int roleID, @PathVariable("roleNO") String roleNO) {
		
		EntityMessage<Teacher> msg = new EntityMessage<Teacher>();
		msg.setFlag(false);
		List<Teacher> teachers = null;
		Iterable<Teacher> it = null;
		Iterator<Teacher> itor = null;
		
		if (roleID > 0) {
			msg.setMessage("操作失败，权限不足");
			return msg;
		}
		/** 按学号/工号查找，学号/工号对应角色不存在 */
		int num = userRepository.findUserNumByNO(roleNO);
		if (num == 0) {
			msg.setMessage("操作失败，请先登录");
			return msg;
		}
		
		teachers = new ArrayList<Teacher>();
		it = teacherRepository.findAll();
		itor = it.iterator();
		while (itor.hasNext()) {
			teachers.add(itor.next());
		}
		msg.setList(teachers);
		msg.setFlag(true);
		msg.setMessage("操作成功");
		return msg;
	}
	@RequestMapping("/delete/user/{roleID}/{roleNO}/{userID}")
	public EntityMessage<User> deleteUser(@PathVariable("roleID") int roleID, @PathVariable("roleNO") String roleNO, 
			@PathVariable("userID") String userID) {
		
		EntityMessage<User> msg = new EntityMessage<User>();
		msg.setFlag(false);
		
		if (roleID > 0) {
			msg.setMessage("操作失败，权限不足");
			return msg;
		}
		/** 按学号/工号查找，学号/工号对应角色不存在 */
		int num = userRepository.findUserNumByNO(roleNO);
		if (num == 0) {
			msg.setMessage("操作失败，请先登录");
			return msg;
		}
		boolean flag = userRepository.exists(Integer.valueOf(userID));
		if(flag) {
			userRepository.delete(Integer.valueOf(userID));
		} else {
			msg.setFlag(false);
			msg.setMessage("该用户已经被删除");
			return msg;
		}
		msg.setFlag(true);
		msg.setMessage("操作成功");
		return msg;
	}

}
