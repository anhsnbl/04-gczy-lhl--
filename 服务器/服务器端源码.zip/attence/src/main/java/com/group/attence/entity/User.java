package com.group.attence.entity;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name = "user")
public class User {

	@Id
	@GeneratedValue(strategy = GenerationType.AUTO)
	private Integer userID;
	private int roleID;
	private String username;
	private String passwd;
	private String telephone;
	private String roleNO;
	
	public User() {}
	public User(String username, String passwd) {
		super();
		this.username = username;
		this.passwd = passwd;
	}
	public User(int roleID, String username, String passwd) {
		super();
		this.roleID = roleID;
		this.username = username;
		this.passwd = passwd;
	}
	public User(int roleID, String username, String passwd, String telephone) {
		super();
		this.roleID = roleID;
		this.username = username;
		this.passwd = passwd;
		this.telephone = telephone;
	}
	public User(int roleID, String username, String passwd, String telephone, String roleNO) {
		super();
		this.roleID = roleID;
		this.username = username;
		this.passwd = passwd;
		this.telephone = telephone;
		this.roleNO = roleNO;
	}
	
	public Integer getUserID() {
		return userID;
	}
	public void setUserID(Integer userID) {
		this.userID = userID;
	}
	public int getRoleID() {
		return roleID;
	}
	public void setRoleID(int roleID) {
		this.roleID = roleID;
	}
	public String getUsername() {
		return username;
	}
	public void setUsername(String username) {
		this.username = username;
	}
	public String getPasswd() {
		return passwd;
	}
	public void setPasswd(String passwd) {
		this.passwd = passwd;
	}
	public String getTelephone() {
		return telephone;
	}
	public void setTelephone(String telephone) {
		this.telephone = telephone;
	}
	public String getRoleNO() {
		return roleNO;
	}
	public void setRoleNO(String roleNO) {
		this.roleNO = roleNO;
	}
	
}
