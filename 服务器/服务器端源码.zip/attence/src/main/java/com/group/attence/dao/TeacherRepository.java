package com.group.attence.dao;

import javax.persistence.Table;

import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.CrudRepository;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import com.group.attence.entity.Teacher;

@Repository
@Table(name = "teacher")
@Qualifier("teacherRepository")
public interface TeacherRepository extends CrudRepository<Teacher, Integer>{

//	public Teacher findOne(Integer id);
//	public Teacher save(Teacher u);
//	public void delete(Integer id);
//	public void delete(Teacher u);
//	public boolean exists(Integer id);
//	public Iterable<Teacher> findAll();
	@Query("select t from Teacher t where t.teacherNO=:teacherNO")
	public Teacher findTeacherByNO(@Param("teacherNO") String teacherNO);
	@Query("select count(t) from Teacher t where t.teacherNO=:teacherNO")
	public int findTeacherNumByNO(@Param("teacherNO") String teacherNO);
	
}
