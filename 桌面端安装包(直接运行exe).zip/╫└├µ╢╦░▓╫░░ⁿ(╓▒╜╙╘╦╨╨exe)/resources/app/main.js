const electron = require('electron')
// 控制应用生命周期的api
const app = electron.app
// 控制本地浏览器窗口的api
const BrowserWindow = electron.BrowserWindow

const path = require('path')
const url = require('url')
// 用于进程通信的api
// var ipc = require('ipc')
const {ipcMain} = require('electron')

// 全局引用
let mainWindow

function createWindow () {
  // 创建窗口
  mainWindow = new BrowserWindow({width: 1200, height: 700,
  webPreferences:{
            nodeIntegration:false,
        }})
  // 加载入口页面
  mainWindow.loadURL(url.format({
    pathname: path.join(__dirname, 'index.html'),
	//pathname: path.join(__dirname, 'index.html'),
    //pathname: path.join(__dirname, 'online-status.html'),
	protocol: 'file:',
    slashes: true
  }))
  //mainWindow.loadURL('https://electron.org.cn/')
  // 打开开发者工具
  //mainWindow.webContents.openDevTools()
  // 窗口事件监听
  mainWindow.on('closed', function () {
    mainWindow = null
  })
}

// 应用事件监听
app.on('ready', createWindow)
app.on('window-all-closed', function () {
  if (process.platform !== 'darwin') {
    app.quit()
  }
})
app.on('activate', function () {
  if (mainWindow === null) {
    createWindow()
  }
})

// 在线/离线事件探测
ipcMain.on('online-status-changed', function(event, status) {
  console.log(status);
  console.log("aaaaaa");
});